import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import {
  galaxyVertex,
  galaxyFragment,
  hazeVertex,
  hazeFragment,
  starVertex,
  starFragment,
  glowVertex,
  glowFragment,
  gradeFragment,
} from './shaders.js';

THREE.ColorManagement.enabled = true;

/* ------------------------------------------------------------------ *
 *  palettes — every layer of the nebula is tinted from here
 * ------------------------------------------------------------------ */
const PALETTES = [
  {
    name: '紫晶 · Amethyst',
    core: '#fff1cf',
    mid: '#a46bff',
    outer: '#4a3bff',
    accent: '#ffd6f2',
    haze: '#6d3bd6',
    haze2: '#2a5fd6',
    nucleus: '#ffe6b8',
    nucleus2: '#c58bff',
    bg: '#07060f',
    ui: '#f3d9a4',
  },
  {
    name: '极光 · Aurora',
    core: '#f4fffe',
    mid: '#3ff0c8',
    outer: '#1f6bff',
    accent: '#dcfff4',
    haze: '#12b79b',
    haze2: '#1d4fc4',
    nucleus: '#e8fff9',
    nucleus2: '#4be0c4',
    bg: '#030a10',
    ui: '#a9f5e2',
  },
  {
    name: '熔金 · Ember',
    core: '#fff8e6',
    mid: '#ff9c4a',
    outer: '#d83b6a',
    accent: '#ffe7b0',
    haze: '#b2431f',
    haze2: '#6f2370',
    nucleus: '#fff2cf',
    nucleus2: '#ff9d54',
    bg: '#0a0507',
    ui: '#ffcf9b',
  },
  {
    name: '深红 · Crimson',
    core: '#fff0f3',
    mid: '#ff4f7d',
    outer: '#7a1bd6',
    accent: '#ffd9e4',
    haze: '#a4144f',
    haze2: '#3c1a9e',
    nucleus: '#ffe4ec',
    nucleus2: '#ff5e8b',
    bg: '#0a0308',
    ui: '#ffb3c4',
  },
];

const PALETTE_KEYS = ['core', 'mid', 'outer', 'accent', 'haze', 'haze2', 'nucleus', 'nucleus2'];
const COLOR_KEYS = ['core', 'mid', 'outer', 'accent'];

/* ------------------------------------------------------------------ *
 *  quality tier
 * ------------------------------------------------------------------ */
const isMobile = /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent) || window.innerWidth < 760;
const QUALITY = isMobile
  ? { pixelRatio: Math.min(window.devicePixelRatio || 1, 1.5), stars: 120000, haze: 1600, field: 2600, bloom: 0.8 }
  : { pixelRatio: Math.min(window.devicePixelRatio || 1, 2), stars: 220000, haze: 3200, field: 4600, bloom: 0.9 };

/* ------------------------------------------------------------------ *
 *  renderer / scene / camera
 * ------------------------------------------------------------------ */
const container = document.getElementById('app');
const loaderEl = document.getElementById('loader');
const loadbarEl = document.getElementById('loadbar');

const renderer = new THREE.WebGLRenderer({
  antialias: false,
  powerPreference: 'high-performance',
  stencil: false,
});
renderer.setPixelRatio(QUALITY.pixelRatio);
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.08;
renderer.outputColorSpace = THREE.SRGBColorSpace;
container.appendChild(renderer.domElement);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 1200);
const HOME = new THREE.Vector3(0, 33, 62);
const INTRO_FROM = new THREE.Vector3(0, 150, 260);
camera.position.copy(INTRO_FROM);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;
controls.rotateSpeed = 0.6;
controls.zoomSpeed = 0.8;
controls.enablePan = false;
controls.minDistance = 14;
controls.maxDistance = 190;
controls.minPolarAngle = 0.14;
controls.maxPolarAngle = Math.PI - 0.14;
controls.enabled = false; // released once the intro dolly lands

const GALAXY_RADIUS = 34;

/* ------------------------------------------------------------------ *
 *  helpers
 * ------------------------------------------------------------------ */
const rand = (a, b) => a + Math.random() * (b - a);
const gauss = () => {
  let u = 0;
  let v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
};

// THREE.Color(hex) converts sRGB -> linear working space for us, which is
// exactly what the additive shaders want before ACES tone mapping.
const toVec3 = (color, out) => out.set(color.r, color.g, color.b);

/* ------------------------------------------------------------------ *
 *  background starfield
 * ------------------------------------------------------------------ */
function buildStarfield(count) {
  const positions = new Float32Array(count * 3);
  const sizes = new Float32Array(count);
  const seeds = new Float32Array(count);

  for (let i = 0; i < count; i++) {
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(rand(-1, 1));
    const r = rand(220, 560);
    positions[i * 3] = Math.sin(phi) * Math.cos(theta) * r;
    positions[i * 3 + 1] = Math.cos(phi) * r;
    positions[i * 3 + 2] = Math.sin(phi) * Math.sin(theta) * r;
    sizes[i] = Math.pow(Math.random(), 2.8) * 3.4 + 0.4;
    seeds[i] = Math.random();
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
  geo.setAttribute('aSeed', new THREE.BufferAttribute(seeds, 1));

  const mat = new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 }, uPixelRatio: { value: QUALITY.pixelRatio } },
    vertexShader: starVertex,
    fragmentShader: starFragment,
    transparent: true,
    depthWrite: false,
    depthTest: false,
    blending: THREE.AdditiveBlending,
  });

  const points = new THREE.Points(geo, mat);
  points.frustumCulled = false;
  points.renderOrder = -10;
  return points;
}

/* ------------------------------------------------------------------ *
 *  the spiral galaxy
 * ------------------------------------------------------------------ */
const galaxyUniforms = {
  uTime: { value: 0 },
  uSize: { value: 1.25 },
  uPixelRatio: { value: QUALITY.pixelRatio },
  uSpin: { value: 0.6 },
  uRadius: { value: GALAXY_RADIUS },
  uTurbulence: { value: 1.1 },
  uCore: { value: new THREE.Vector3() },
  uMid: { value: new THREE.Vector3() },
  uOuter: { value: new THREE.Vector3() },
  uAccent: { value: new THREE.Vector3() },
};

const ARM_COUNT = 4;
const ARM_TIGHTNESS = 4.1;

function buildGalaxy(count) {
  const positions = new Float32Array(count * 3);
  const radius = new Float32Array(count);
  const sizes = new Float32Array(count);
  const seeds = new Float32Array(count);
  const density = new Float32Array(count);

  const CORE_RATIO = 0.15;

  for (let i = 0; i < count; i++) {
    const isCore = Math.random() < CORE_RATIO;
    let r, angle, height;

    if (isCore) {
      // bulge — dense, puffy, mildly flattened
      r = Math.pow(Math.random(), 2.2) * GALAXY_RADIUS * 0.28;
      angle = Math.random() * Math.PI * 2;
      height = gauss() * (0.7 + r * 0.1);
    } else {
      r = Math.pow(Math.random(), 1.4) * GALAXY_RADIUS;
      const armAngle = Math.floor(Math.random() * ARM_COUNT) / ARM_COUNT * Math.PI * 2;
      const scatter = (0.14 + (r / GALAXY_RADIUS) * 0.9) * gauss() * 0.5;
      angle = armAngle + Math.log(1 + r * 0.085) * ARM_TIGHTNESS + scatter;
      // a minority of stars drift between the arms as an even haze
      if (Math.random() < 0.24) angle = Math.random() * Math.PI * 2;
      height = gauss() * (0.22 + r * 0.016);
    }

    const rad = r + gauss() * (isCore ? 0.5 : 0.3 + r * 0.01);
    const px = Math.cos(angle) * rad;
    const pz = Math.sin(angle) * rad;

    positions[i * 3] = px;
    positions[i * 3 + 1] = height;
    positions[i * 3 + 2] = pz;

    radius[i] = Math.max(0.01, Math.hypot(px, pz));
    sizes[i] = isCore
      ? rand(0.5, 1.35)
      : rand(0.24, 0.95) * (Math.random() < 0.012 ? 2.3 : 1);
    seeds[i] = Math.random();
    density[i] = isCore ? rand(0.65, 1) : 0.45 + Math.random() * 0.55;
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('aRadius', new THREE.BufferAttribute(radius, 1));
  geo.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
  geo.setAttribute('aSeed', new THREE.BufferAttribute(seeds, 1));
  geo.setAttribute('aDensity', new THREE.BufferAttribute(density, 1));

  const mat = new THREE.ShaderMaterial({
    uniforms: galaxyUniforms,
    vertexShader: galaxyVertex,
    fragmentShader: galaxyFragment,
    transparent: true,
    depthWrite: false,
    depthTest: false,
    blending: THREE.AdditiveBlending,
  });

  const points = new THREE.Points(geo, mat);
  points.frustumCulled = false;
  points.renderOrder = 1;
  return points;
}

/* ------------------------------------------------------------------ *
 *  dust / nebula haze
 * ------------------------------------------------------------------ */
const hazeUniforms = {
  uTime: { value: 0 },
  uSpin: { value: 0.6 },
  uRadius: { value: GALAXY_RADIUS },
  uPixelRatio: { value: QUALITY.pixelRatio },
  uHaze: { value: new THREE.Vector3() },
  uHaze2: { value: new THREE.Vector3() },
  uOpacity: { value: 0.4 },
};

function buildHaze(count) {
  const positions = new Float32Array(count * 3);
  const radius = new Float32Array(count);
  const sizes = new Float32Array(count);
  const seeds = new Float32Array(count);

  for (let i = 0; i < count; i++) {
    const r = Math.pow(Math.random(), 0.9) * GALAXY_RADIUS * 0.97;
    const armAngle = Math.floor(Math.random() * ARM_COUNT) / ARM_COUNT * Math.PI * 2;
    const scatter = (0.1 + (r / GALAXY_RADIUS) * 0.7) * gauss() * 0.3;
    const angle = armAngle + Math.log(1 + r * 0.085) * ARM_TIGHTNESS + scatter;

    positions[i * 3] = Math.cos(angle) * r;
    positions[i * 3 + 1] = gauss() * (0.4 + r * 0.02);
    positions[i * 3 + 2] = Math.sin(angle) * r;

    radius[i] = Math.max(0.01, r);
    sizes[i] = rand(5, 19) * (1 - (r / GALAXY_RADIUS) * 0.3);
    seeds[i] = Math.random();
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('aRadius', new THREE.BufferAttribute(radius, 1));
  geo.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
  geo.setAttribute('aSeed', new THREE.BufferAttribute(seeds, 1));

  const mat = new THREE.ShaderMaterial({
    uniforms: hazeUniforms,
    vertexShader: hazeVertex,
    fragmentShader: hazeFragment,
    transparent: true,
    depthWrite: false,
    depthTest: false,
    blending: THREE.AdditiveBlending,
  });

  const points = new THREE.Points(geo, mat);
  points.frustumCulled = false;
  points.renderOrder = 0;
  return points;
}

/* ------------------------------------------------------------------ *
 *  galactic nucleus glow
 * ------------------------------------------------------------------ */
const glowUniforms = {
  uColor: { value: new THREE.Vector3() },
  uColor2: { value: new THREE.Vector3() },
  uIntensity: { value: 0.85 },
  uTime: { value: 0 },
  uSharpness: { value: 1.1 },
};

function buildNucleus() {
  const mat = new THREE.ShaderMaterial({
    uniforms: glowUniforms,
    vertexShader: glowVertex,
    fragmentShader: glowFragment,
    transparent: true,
    depthWrite: false,
    depthTest: false,
    blending: THREE.AdditiveBlending,
  });
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(72, 72), mat);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.y = 0.05;
  mesh.renderOrder = -1;
  mesh.frustumCulled = false;
  return mesh;
}

/* ------------------------------------------------------------------ *
 *  assemble the disc into one tilting group
 * ------------------------------------------------------------------ */
const disc = new THREE.Group();
const starfield = buildStarfield(QUALITY.field);
const galaxy = buildGalaxy(QUALITY.stars);
const haze = buildHaze(QUALITY.haze);
const nucleus = buildNucleus();

disc.add(haze, galaxy, nucleus);
disc.rotation.x = 0.12;
scene.add(starfield, disc);

/* ------------------------------------------------------------------ *
 *  post-processing
 * ------------------------------------------------------------------ */
const composer = new EffectComposer(renderer);
composer.setPixelRatio(QUALITY.pixelRatio);
composer.setSize(window.innerWidth, window.innerHeight);
composer.addPass(new RenderPass(scene, camera));

const bloom = new UnrealBloomPass(
  new THREE.Vector2(window.innerWidth, window.innerHeight),
  QUALITY.bloom,
  0.78,
  0.14
);
composer.addPass(bloom);

const gradePass = new ShaderPass({
  uniforms: {
    tDiffuse: { value: null },
    uTime: { value: 0 },
    uResolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
    uAberration: { value: 0.0045 },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: gradeFragment,
});
composer.addPass(gradePass);
composer.addPass(new OutputPass());

/* ------------------------------------------------------------------ *
 *  palette cross-fade
 * ------------------------------------------------------------------ */
const current = {};
const target = {};
for (const key of PALETTE_KEYS) {
  current[key] = new THREE.Color(PALETTES[0][key]);
  target[key] = new THREE.Color(PALETTES[0][key]);
}
const bgCurrent = new THREE.Color(PALETTES[0].bg);
const bgTarget = new THREE.Color(PALETTES[0].bg);
const bgFinal = new THREE.Color(PALETTES[0].bg);

function setPalette(index) {
  const p = PALETTES[index];
  for (const key of PALETTE_KEYS) target[key].set(p[key]);
  bgTarget.set(p.bg);

  document.querySelectorAll('.swatch').forEach((el, i) => {
    el.classList.toggle('active', i === index);
  });
  const root = document.documentElement.style;
  root.setProperty('--gold', p.ui);
  root.setProperty('--gold-dim', p.ui + 'a6');
  root.setProperty('--glow', p.mid);
}

function updatePalette(dt) {
  const k = 1 - Math.pow(0.0015, dt);
  for (const key of PALETTE_KEYS) current[key].lerp(target[key], k);
  bgCurrent.lerp(bgTarget, k);

  toVec3(current.core, galaxyUniforms.uCore.value);
  toVec3(current.mid, galaxyUniforms.uMid.value);
  toVec3(current.outer, galaxyUniforms.uOuter.value);
  toVec3(current.accent, galaxyUniforms.uAccent.value);

  toVec3(current.haze, hazeUniforms.uHaze.value);
  toVec3(current.haze2, hazeUniforms.uHaze2.value);

  toVec3(current.nucleus, glowUniforms.uColor.value);
  toVec3(current.nucleus2, glowUniforms.uColor2.value);

  // background follows the scheme, a shade darker than the authored value
  bgFinal.copy(bgCurrent).multiplyScalar(0.8);
  scene.background = bgFinal;
  renderer.setClearColor(bgFinal, 1);
}

/* ------------------------------------------------------------------ *
 *  UI
 * ------------------------------------------------------------------ */
let autoSpin = true;
const btnSpin = document.getElementById('btn-spin');
const btnReset = document.getElementById('btn-reset');

btnSpin.addEventListener('click', () => {
  autoSpin = !autoSpin;
  btnSpin.setAttribute('aria-pressed', String(autoSpin));
});

let resetTween = null;
btnReset.addEventListener('click', () => {
  resetTween = { t: 0, from: camera.position.clone() };
  controls.enabled = false;
});

document.querySelectorAll('.swatch').forEach((el) => {
  el.addEventListener('click', () => setPalette(Number(el.dataset.palette)));
});

const statCount = document.getElementById('stat-count');
const statFps = document.getElementById('stat-fps');
const statDist = document.getElementById('stat-dist');
statCount.textContent = (QUALITY.stars + QUALITY.haze + QUALITY.field).toLocaleString('en-US');

/* ------------------------------------------------------------------ *
 *  pointer parallax
 * ------------------------------------------------------------------ */
const pointer = { x: 0, y: 0 };
const smoothPointer = { x: 0, y: 0 };

window.addEventListener('pointermove', (e) => {
  pointer.x = (e.clientX / window.innerWidth) * 2 - 1;
  pointer.y = (e.clientY / window.innerHeight) * 2 - 1;
});

// touching the galaxy skips the intro dolly
renderer.domElement.addEventListener('pointerdown', () => {
  if (introProgress < 1) finishIntro();
});

/* ------------------------------------------------------------------ *
 *  resize
 * ------------------------------------------------------------------ */
function onResize() {
  const w = window.innerWidth;
  const h = window.innerHeight;
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  renderer.setSize(w, h);
  composer.setSize(w, h);
  bloom.setSize(w, h);
  gradePass.uniforms.uResolution.value.set(w, h);
}
window.addEventListener('resize', onResize);

/* ------------------------------------------------------------------ *
 *  animation
 * ------------------------------------------------------------------ */
const clock = new THREE.Clock();
const clockStart = performance.now();
let elapsed = 0;
let introProgress = 0;
let fpsAccum = 0;
let fpsFrames = 0;
let spinTargetValue = 0.6;

function finishIntro() {
  introProgress = 1;
  camera.position.copy(HOME);
  controls.enabled = true;
}

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);
  elapsed += dt;

  /* ---- cinematic intro dolly ---- */
  if (introProgress < 1) {
    introProgress = Math.min(1, introProgress + dt * 0.22);
    const e = 1 - Math.pow(1 - introProgress, 4);
    camera.position.lerpVectors(INTRO_FROM, HOME, e);
    if (introProgress >= 1) controls.enabled = true;
  }

  /* ---- rotational flow, eased on toggle ---- */
  spinTargetValue = autoSpin ? 0.6 : 0.02;
  const spinEase = Math.min(1, dt * 1.8);
  galaxyUniforms.uSpin.value += (spinTargetValue - galaxyUniforms.uSpin.value) * spinEase;
  hazeUniforms.uSpin.value = galaxyUniforms.uSpin.value;

  galaxyUniforms.uTime.value = elapsed;
  hazeUniforms.uTime.value = elapsed;
  starfield.material.uniforms.uTime.value = elapsed;
  glowUniforms.uTime.value = elapsed;
  gradePass.uniforms.uTime.value = elapsed;

  /* ---- pointer-driven tilt ---- */
  smoothPointer.x += (pointer.x - smoothPointer.x) * Math.min(1, dt * 2.2);
  smoothPointer.y += (pointer.y - smoothPointer.y) * Math.min(1, dt * 2.2);

  const tiltX = 0.12 - smoothPointer.y * 0.16;
  const tiltZ = smoothPointer.x * 0.1;
  disc.rotation.x += (tiltX - disc.rotation.x) * Math.min(1, dt * 1.4);
  disc.rotation.z += (tiltZ - disc.rotation.z) * Math.min(1, dt * 1.4);

  // slow orbital drift of the whole disc (~90s per revolution)
  if (autoSpin) disc.rotation.y += dt * 0.07;

  /* ---- camera reset tween ---- */
  if (resetTween) {
    resetTween.t = Math.min(1, resetTween.t + dt * 0.8);
    const e = 1 - Math.pow(1 - resetTween.t, 3);
    const from = new THREE.Spherical().setFromVector3(resetTween.from);
    const to = new THREE.Spherical().setFromVector3(HOME);
    const s = new THREE.Spherical(
      THREE.MathUtils.lerp(from.radius, to.radius, e),
      THREE.MathUtils.lerp(from.phi, to.phi, e),
      THREE.MathUtils.lerp(from.theta, to.theta, e)
    );
    camera.position.setFromSpherical(s);
    if (resetTween.t >= 1) {
      resetTween = null;
      controls.enabled = true;
    }
  }

  updatePalette(dt);
  controls.update();
  composer.render();

  /* ---- HUD readouts ---- */
  fpsAccum += dt;
  fpsFrames++;
  if (fpsAccum > 0.5) {
    statFps.textContent = Math.round(fpsFrames / fpsAccum);
    statDist.textContent = camera.position.length().toFixed(1) + ' kly';
    fpsAccum = 0;
    fpsFrames = 0;
  }
}

/* ------------------------------------------------------------------ *
 *  boot
 * ------------------------------------------------------------------ */
setPalette(0);
updatePalette(1);
animate();

let progress = 0;
const barTimer = setInterval(() => {
  progress = Math.min(100, progress + rand(8, 24));
  loadbarEl.style.width = progress + '%';
  if (progress >= 100) {
    clearInterval(barTimer);
    setTimeout(() => {
      loaderEl.classList.add('done');
      document.body.classList.add('ready');
    }, 260);
  }
}, 120);

/* ---- keyboard shortcuts ---- */
window.addEventListener('keydown', (e) => {
  if (e.code === 'Space') {
    e.preventDefault();
    btnSpin.click();
  } else if (e.code === 'KeyR') {
    btnReset.click();
  } else if (e.code === 'KeyF') {
    if (document.fullscreenElement) document.exitFullscreen();
    else document.documentElement.requestFullscreen?.();
  } else {
    const n = Number(e.key);
    if (n >= 1 && n <= PALETTES.length) setPalette(n - 1);
  }
});

// two-second "did you know" nudge for the loader, purely cosmetic timing guard
setTimeout(() => {
  if (!document.body.classList.contains('ready')) {
    loaderEl.classList.add('done');
    document.body.classList.add('ready');
  }
}, 2600);
