/**
 * GLSL programs for the galaxy scene.
 * Particle colours are computed procedurally so the whole nebula can be
 * re-tinted at runtime by lerping a handful of uniforms.
 */

export const galaxyVertex = /* glsl */ `
  uniform float uTime;
  uniform float uSize;
  uniform float uPixelRatio;
  uniform float uSpin;
  uniform float uRadius;
  uniform float uTurbulence;

  uniform vec3 uCore;
  uniform vec3 uMid;
  uniform vec3 uOuter;
  uniform vec3 uAccent;

  attribute float aRadius;
  attribute float aSize;
  attribute float aSeed;
  attribute float aDensity;

  varying vec3 vColor;
  varying float vAlpha;
  varying float vTwinkle;

  vec3 rotateY(vec3 p, float a) {
    float c = cos(a);
    float s = sin(a);
    return vec3(c * p.x + s * p.z, p.y, -s * p.x + c * p.z);
  }

  void main() {
    float r = clamp(aRadius / uRadius, 0.0, 1.0);

    // ---- differential rotation: inner stars orbit faster (Keplerian-ish)
    float omega = 0.85 / (0.22 + pow(r, 0.75));
    float angle = uTime * uSpin * omega;

    vec3 p = rotateY(position, angle);

    // ---- slow breathing turbulence, strongest in the outer disc
    float wob = sin(uTime * 0.55 + aSeed * 18.0 + r * 7.0);
    p.y += wob * uTurbulence * (0.25 + r) * 0.55;
    float radial = sin(uTime * 0.4 + aSeed * 27.0) * uTurbulence * 0.7 * r;
    p.xz += normalize(position.xz + 0.0001) * radial;

    vec4 mvPosition = modelViewMatrix * vec4(p, 1.0);

    // ---- colour: hot core -> violet middle -> cold blue rim
    vec3 col = mix(uCore, uMid, smoothstep(0.0, 0.52, r));
    col = mix(col, uOuter, smoothstep(0.46, 1.0, r));

    // young blue-white clusters strung along the arms
    float young = smoothstep(0.62, 0.95, aSeed) * smoothstep(0.12, 0.55, r);
    col = mix(col, uAccent, young * 0.55);

    // hidden core glow
    float core = 1.0 - smoothstep(0.0, 0.2, r);
    col += uCore * core * 0.9;

    float twinkle = 0.72 + 0.28 * sin(uTime * 1.7 + aSeed * 91.0);
    vTwinkle = twinkle;

    vColor = col;
    vAlpha = aDensity * (0.45 + 0.55 * smoothstep(0.0, 0.06, r));

    float size = aSize * (0.8 + 0.85 * (1.0 - r));
    gl_PointSize = clamp(
      size * uSize * uPixelRatio * (44.0 / max(0.4, -mvPosition.z)),
      0.6,
      64.0
    );

    gl_Position = projectionMatrix * mvPosition;
  }
`;

export const galaxyFragment = /* glsl */ `
  varying vec3 vColor;
  varying float vAlpha;
  varying float vTwinkle;

  void main() {
    vec2 uv = gl_PointCoord - 0.5;
    float d = length(uv);

    float halo = smoothstep(0.5, 0.0, d);
    float glow = pow(halo, 3.2);
    float spark = pow(halo, 12.0);

    float a = (glow * 0.85 + spark * 1.4) * vAlpha * vTwinkle;
    if (a < 0.002) discard;

    vec3 col = vColor * (0.55 + spark * 1.9);
    col += vec3(1.0) * spark * 0.35;

    gl_FragColor = vec4(col, a);
  }
`;

export const hazeVertex = /* glsl */ `
  uniform float uTime;
  uniform float uSpin;
  uniform float uRadius;
  uniform float uPixelRatio;

  attribute float aRadius;
  attribute float aSize;
  attribute float aSeed;

  varying float vFade;
  varying float vSeed;

  vec3 rotateY(vec3 p, float a) {
    float c = cos(a);
    float s = sin(a);
    return vec3(c * p.x + s * p.z, p.y, -s * p.x + c * p.z);
  }

  void main() {
    float r = clamp(aRadius / uRadius, 0.0, 1.0);
    float omega = 0.85 / (0.22 + pow(r, 0.75));
    vec3 p = rotateY(position, uTime * uSpin * omega * 0.92);

    vec4 mvPosition = modelViewMatrix * vec4(p, 1.0);
    vFade = (1.0 - smoothstep(0.55, 1.0, r)) * 0.55 + 0.16;
    vFade *= 0.55 + 0.45 * sin(uTime * 0.3 + aSeed * 40.0);
    vSeed = aSeed;

    gl_PointSize = clamp(aSize * uPixelRatio * (240.0 / max(1.0, -mvPosition.z)), 1.0, 460.0);
    gl_Position = projectionMatrix * mvPosition;
  }
`;

export const hazeFragment = /* glsl */ `
  uniform vec3 uHaze;
  uniform vec3 uHaze2;
  uniform float uOpacity;

  varying float vFade;
  varying float vSeed;

  void main() {
    vec2 uv = gl_PointCoord - 0.5;
    float d = length(uv);
    float a = smoothstep(0.5, 0.0, d);
    a = pow(a, 2.4) * vFade * uOpacity;
    if (a < 0.002) discard;

    vec3 col = mix(uHaze, uHaze2, vSeed);
    gl_FragColor = vec4(col, a);
  }
`;

/** Static background starfield that twinkles gently. */
export const starVertex = /* glsl */ `
  uniform float uTime;
  uniform float uPixelRatio;

  attribute float aSize;
  attribute float aSeed;

  varying float vAlpha;
  varying vec3 vColor;

  void main() {
    vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
    gl_Position = projectionMatrix * mvPosition;

    float t = sin(uTime * (0.5 + aSeed * 1.8) + aSeed * 120.0);
    vAlpha = 0.35 + 0.65 * pow(0.5 + 0.5 * t, 2.0);

    vec3 warm = vec3(1.0, 0.86, 0.68);
    vec3 cool = vec3(0.72, 0.84, 1.0);
    vColor = mix(cool, warm, fract(aSeed * 7.13));

    gl_PointSize = clamp(aSize * uPixelRatio * (330.0 / max(1.0, -mvPosition.z)), 0.7, 26.0);
  }
`;

export const starFragment = /* glsl */ `
  varying float vAlpha;
  varying vec3 vColor;

  void main() {
    float d = length(gl_PointCoord - 0.5);
    float a = smoothstep(0.5, 0.0, d);
    a = pow(a, 2.0) * vAlpha;
    if (a < 0.004) discard;
    gl_FragColor = vec4(vColor, a);
  }
`;

/** Radial sprite used for the galactic nucleus and its halo. */
export const glowVertex = /* glsl */ `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

export const glowFragment = /* glsl */ `
  uniform vec3 uColor;
  uniform vec3 uColor2;
  uniform float uIntensity;
  uniform float uTime;
  uniform float uSharpness;

  varying vec2 vUv;

  void main() {
    vec2 p = vUv - 0.5;
    float d = length(p) * 2.0;

    float core = pow(max(0.0, 1.0 - d), uSharpness * 7.0);
    float halo = pow(max(0.0, 1.0 - d), 2.2) * 0.5;
    float pulse = 0.9 + 0.1 * sin(uTime * 1.2);

    // anamorphic streak
    float streak = max(0.0, 1.0 - abs(p.y) * 42.0) * pow(max(0.0, 1.0 - abs(p.x) * 2.0), 3.0);
    streak *= 0.5;

    float a = (core * 1.4 + halo + streak) * uIntensity * pulse;
    vec3 col = mix(uColor2, uColor, clamp(core + halo * 0.4, 0.0, 1.0));
    col += vec3(1.0) * core * 0.6;

    gl_FragColor = vec4(col, a);
  }
`;

/** Final grade: subtle chromatic aberration, grain, vignette and dithering. */
export const gradeFragment = /* glsl */ `
  uniform sampler2D tDiffuse;
  uniform float uTime;
  uniform vec2 uResolution;
  uniform float uAberration;

  varying vec2 vUv;

  float rand(vec2 co) {
    return fract(sin(dot(co, vec2(12.9898, 78.233))) * 43758.5453);
  }

  void main() {
    vec2 uv = vUv;
    vec2 centered = uv - 0.5;
    float r2 = dot(centered, centered);

    float ab = uAberration * (0.15 + r2 * 1.6);
    vec3 col;
    col.r = texture2D(tDiffuse, uv + centered * ab).r;
    col.g = texture2D(tDiffuse, uv).g;
    col.b = texture2D(tDiffuse, uv - centered * ab).b;

    // soft vignette
    col *= 1.0 - r2 * 0.75;

    // film grain
    float grain = rand(uv * uResolution + fract(uTime) * 91.7) - 0.5;
    col += grain * 0.022;

    // gentle contrast lift
    col = pow(max(col, 0.0), vec3(1.04));

    gl_FragColor = vec4(col, 1.0);
  }
`;
