#!/usr/bin/env bash
# 启动本地静态服务并打开页面（ES Module 不能直接双击 file:// 打开）
cd "$(dirname "$0")" || exit 1
PORT="${PORT:-5173}"
echo "→ http://localhost:$PORT"
( sleep 1; command -v open >/dev/null && open "http://localhost:$PORT"; command -v xdg-open >/dev/null && xdg-open "http://localhost:$PORT" ) >/dev/null 2>&1 &
if command -v python3 >/dev/null; then
  python3 -m http.server "$PORT" --bind 127.0.0.1
elif command -v python >/dev/null; then
  python -m http.server "$PORT" --bind 127.0.0.1
else
  npx --yes serve -l "$PORT" .
fi
