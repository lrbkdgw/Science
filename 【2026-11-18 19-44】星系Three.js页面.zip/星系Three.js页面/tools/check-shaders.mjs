// Minimal WebGL2 / GLSL sanity tests for the scene shaders.
// Run with: node tools/check-shaders.mjs
// Uses a tiny CPU "compiler" pass: texture unit / varying budget checks plus
// matching each `varying` declared in a vertex shader with its fragment use.
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const src = await readFile(path.join(root, 'src/shaders.js'), 'utf8');

// the grade pass lives inline in main.js, the rest are exported from shaders.js
const progs = ['galaxy', 'haze', 'star', 'glow'];
let failures = 0;

const grab = (name) => {
  const m = src.match(new RegExp(`export const ${name} = /\\* glsl \\*/ \`([\\s\\S]*?)\`;`));
  return m ? m[1] : null;
};

const varyingNames = (code) =>
  [...code.matchAll(/^\s*varying\s+(?:float|vec[234]|mat[234])\s+(\w+)\s*;/gm)].map((m) => m[1]);

const attrs = (code) =>
  [...code.matchAll(/^\s*attribute\s+(?:float|vec[234])\s+(\w+)\s*;/gm)].map((m) => m[1]);

const uniforms = (code) =>
  [...code.matchAll(/^\s*uniform\s+(?:float|vec[234]|sampler2D)\s+(\w+)\s*;/gm)].map((m) => m[1]);

for (const name of progs) {
  const vs = grab(`${name}Vertex`);
  const fs = grab(`${name}Fragment`);
  if (!vs || !fs) {
    console.error(`✗ ${name}: shader source missing`);
    failures++;
    continue;
  }

  const vOut = varyingNames(vs);
  const fIn = varyingNames(fs);

  // every varying written by the vertex shader must exist in the fragment shader
  for (const v of vOut) {
    if (!fIn.includes(v)) {
      console.error(`✗ ${name}: varying "${v}" not declared in fragment shader`);
      failures++;
    }
  }
  if (vOut.length > 8) {
    console.error(`✗ ${name}: ${vOut.length} varyings (WebGL minimum is 8)`);
    failures++;
  }

  // braces / parens balance
  const balance = (code, open, close) => {
    let d = 0;
    for (const ch of code) {
      if (ch === open) d++;
      if (ch === close) d--;
      if (d < 0) return false;
    }
    return d === 0;
  };
  for (const [code, label] of [[vs, 'vertex'], [fs, 'fragment']]) {
    let stripped = code.replace(/\/\/.*$/gm, '');
    if (!balance(stripped, '{', '}')) {
      console.error(`✗ ${name}: unbalanced braces in ${label} shader`);
      failures++;
    }
    if (!balance(stripped, '(', ')')) {
      console.error(`✗ ${name}: unbalanced parens in ${label} shader`);
      failures++;
    }
    if (!/void\s+main\s*\(\s*\)/.test(stripped)) {
      console.error(`✗ ${name}: no main() in ${label} shader`);
      failures++;
    }
    // gl_PointSize is required for every Points material
    if (label === 'vertex' && name !== 'glow' && !/gl_PointSize/.test(stripped)) {
      console.error(`✗ ${name}: vertex shader never sets gl_PointSize`);
      failures++;
    }
    if (label === 'fragment' && !/gl_FragColor/.test(stripped)) {
      console.error(`✗ ${name}: fragment shader never writes gl_FragColor`);
      failures++;
    }
  }

  console.log(
    `✓ ${name}: ${vOut.length} varying(s) [${vOut.join(', ')}], ` +
      `${attrs(vs).length} attribute(s), ${uniforms(vs).length + uniforms(fs).length} uniform slot(s)`
  );
}

// attributes requested by the shaders must be present in main.js geometry setup
const main = await readFile(path.join(root, 'src/main.js'), 'utf8');
const declaredAttrs = new Set(progs.flatMap((n) => attrs(grab(`${n}Vertex`) || '')));
const provided = new Set([...main.matchAll(/setAttribute\(\s*'(\w+)'/g)].map((m) => m[1]));
for (const a of declaredAttrs) {
  if (!provided.has(a)) {
    console.error(`✗ attribute "${a}" is declared in GLSL but never uploaded`);
    failures++;
  }
}

// the grade pass: fragment shader exported, vertex shader inline in main.js
const gradeFs = grab('gradeFragment');
if (!gradeFs || !/varying\s+vec2\s+vUv/.test(gradeFs)) {
  console.error('✗ grade: fragment shader missing or lost its vUv varying');
  failures++;
} else if (!/varying\s+vec2\s+vUv/.test(main)) {
  console.error('✗ grade: vertex shader in main.js does not pass vUv');
  failures++;
} else {
  console.log('✓ grade: chromatic aberration / grain / vignette pass');
}

if (failures) {
  console.error(`\n${failures} shader check(s) failed.`);
  process.exit(1);
}
console.log('\nAll shader checks passed.');
