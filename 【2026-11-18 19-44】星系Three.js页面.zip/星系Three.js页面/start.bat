@echo off
rem 启动本地静态服务并打开页面（需要已安装 Python 或 Node.js）
cd /d "%~dp0"
set PORT=5173
echo Open http://localhost:%PORT%
start "" http://localhost:%PORT%
where python >nul 2>nul && (python -m http.server %PORT% --bind 127.0.0.1 & goto :eof)
where py >nul 2>nul && (py -m http.server %PORT% --bind 127.0.0.1 & goto :eof)
npx --yes serve -l %PORT% .
