import * as THREE from 'three';

const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const clamp = THREE.MathUtils.clamp;
const lerp = THREE.MathUtils.lerp;

function randomSource(seed) {
  return () => { seed = (Math.imul(1664525, seed) + 1013904223) >>> 0; return seed / 4294967296; };
}

const pointVertex = /* glsl */`
  attribute vec3 shade;
  attribute float size;
  attribute float strength;
  uniform float density;
  varying vec3 vShade;
  varying float vStrength;
  varying float vSize;
  void main() {
    vShade = shade;
    vStrength = strength;
    vSize = size;
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    gl_Position = projectionMatrix * mv;
    gl_PointSize = max(1.0, size * density * clamp(12.0 / -mv.z, 0.64, 1.5));
  }
`;
const pointFragment = /* glsl */`
  uniform float time;
  uniform float opacity;
  varying vec3 vShade;
  varying float vStrength;
  varying float vSize;
  void main() {
    vec2 p = abs(gl_PointCoord - 0.5) * 2.0;
    float d = length(p);
    float soft = exp(-5.2 * d * d) * (1.0 - smoothstep(0.62, 1.0, d));
    float core = exp(-22.0 * d * d);
    float rays = (exp(-35.0 * p.x) + exp(-35.0 * p.y)) * (1.0 - smoothstep(0.02, 0.93, d));
    float detail = step(5.0, vSize);
    float flicker = 0.86 + 0.14 * sin(time * 0.78 + vStrength * 92.0 + vShade.b * 6.0);
    gl_FragColor = vec4(vShade, (soft * 0.66 + core * 0.45 + rays * detail * 0.68) * flicker * vStrength * opacity);
  }
`;

function pointCloud(positions, colors, sizes, strengths) {
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('shade', new THREE.Float32BufferAttribute(colors, 3));
  geo.setAttribute('size', new THREE.Float32BufferAttribute(sizes, 1));
  geo.setAttribute('strength', new THREE.Float32BufferAttribute(strengths, 1));
  const material = new THREE.ShaderMaterial({
    uniforms: { time: { value: 0 }, density: { value: 1 }, opacity: { value: 1 } },
    vertexShader: pointVertex, fragmentShader: pointFragment, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
  });
  return new THREE.Points(geo, material);
}

function makeField() {
  const rand = randomSource(33);
  const positions = [], colors = [], sizes = [], strengths = [];
  for (let i = 0; i < 2050; i++) {
    const z = -rand() * 14 - 1;
    const depth = (12 - z) / 12;
    const bright = i < 32;
    positions.push((rand() * 2 - 1) * 5.3 * depth, (rand() * 2 - 1) * 5 * depth, z);
    const tint = rand();
    colors.push(tint > .88 ? 1 : .66 + tint * .31, .57 + tint * .37, tint > .88 ? .85 : 1);
    sizes.push(bright ? 7 + rand() * 9 : 1.1 + Math.pow(rand(), 2.4) * 3.25);
    strengths.push(bright ? .63 + rand() * .33 : .21 + rand() * .59);
  }
  return pointCloud(positions, colors, sizes, strengths);
}

function makeGalaxy(texture) {
  const photo = texture.image;
  const aspect = photo.height / photo.width;
  texture.anisotropy = 4;
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(1, aspect, 52, 36), new THREE.ShaderMaterial({
    uniforms: { map: { value: texture }, fade: { value: 0 } },
    vertexShader: /* glsl */`
      varying vec2 texUv;
      void main() {
        texUv = uv;
        vec3 p = position;
        p.z += .056 * exp(-15.0 * dot(p.xy,p.xy)) - .05 * p.x * p.y;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
      }
    `,
    fragmentShader: /* glsl */`
      uniform sampler2D map;
      uniform float fade;
      varying vec2 texUv;
      void main() {
        vec3 rgb = texture2D(map, texUv).rgb;
        vec2 edges = min(texUv, 1.0 - texUv);
        float border = smoothstep(.018, .14, edges.x) * smoothstep(.018, .15, edges.y);
        float rad = 1.0 - smoothstep(.76, 1.25, length((texUv - .5) * 2.0));
        float brightness = max(rgb.r, max(rgb.g, rgb.b));
        vec3 color = mix(vec3(dot(rgb, vec3(.299, .587, .114))), rgb, 1.24) * vec3(1.05, .975, 1.085);
        gl_FragColor = vec4(color, border * rad * smoothstep(.035, .25, brightness) * fade);
      }
    `,
    transparent: true, side: THREE.DoubleSide, depthWrite: false,
  }));
  mesh.renderOrder = 1;

  // Sample the illustrated galaxy's dust lanes and give the luminous points real depth.
  const sampler = document.createElement('canvas');
  sampler.width = 250;
  sampler.height = Math.round(sampler.width * aspect);
  const ctx = sampler.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(photo, 0, 0, sampler.width, sampler.height);
  const pixels = ctx.getImageData(0, 0, sampler.width, sampler.height).data;
  const rand = randomSource(531);
  const positions = [], colors = [], sizes = [], strengths = [];
  for (let i = 0; i < 25500; i++) {
    const x = rand() * .94 + .03, y = rand() * .92 + .04;
    const pixel = 4 * (Math.floor(y * sampler.height) * sampler.width + Math.floor(x * sampler.width));
    const r = pixels[pixel] / 255, g = pixels[pixel + 1] / 255, b = pixels[pixel + 2] / 255;
    const intensity = (r + g + b) / 3;
    if (intensity < .19 || rand() > intensity * .49) continue;
    const ox = x - .5, oy = (.5 - y) * aspect;
    const thickness = Math.exp(-11 * (ox * ox + oy * oy));
    positions.push(ox, oy, .052 * thickness + (rand() - .38) * (.047 + .09 * thickness));
    colors.push(.70 + r * .30, .51 + g * .48, .77 + b * .23);
    sizes.push(1 + rand() * 2.2 + (rand() > .996 ? 4 : 0));
    strengths.push((.12 + rand() * .45) * Math.max(.38, 1 - intensity * .65));
  }
  const points = pointCloud(positions, colors, sizes, strengths);
  points.renderOrder = 2;
  const group = new THREE.Group();
  group.add(mesh, points);
  return { group, mesh, points, fade: 0 };
}

export function createViewer(element, onZoom, onFallback) {
  let renderer;
  try { renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'high-performance' }); } catch { /* static fallback below */ }
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(42, 1, .1, 70);
  camera.position.z = 12;
  const subject = new THREE.Group();
  const field = makeField();
  const fallImage = document.createElement('img');
  fallImage.className = 'fallback-galaxy';
  fallImage.alt = '';
  let working = !!renderer;
  let asset, displayedAsset, zoom = 1, smoothZoom = 1, auto = !reducedMotion, turn = 0;
  let pitch = 0, yaw = 0, spin = 0, width = 1, height = 1, density = 1;
  let frame = 0, last = 0, centerX = .59, centerY = .46;
  const models = new Map();
  const loader = new THREE.TextureLoader();
  const pointers = new Map();
  let pinch = 0;
  scene.add(subject, field);

  function fallback() {
    working = false;
    cancelAnimationFrame(frame);
    renderer?.domElement.remove();
    element.classList.add('static');
    element.append(fallImage);
    if (asset) fallImage.src = asset;
    auto = false;
    updateFallback();
    onFallback();
  }
  function updateFallback() {
    fallImage.style.setProperty('--scale', zoom);
    fallImage.style.setProperty('--tilt', `${yaw * 30}deg`);
  }
  function resize() {
    width = element.clientWidth || 1;
    height = element.clientHeight || 1;
    const styles = getComputedStyle(element.parentElement);
    centerX = parseFloat(styles.getPropertyValue('--cx')) / 100;
    centerY = parseFloat(styles.getPropertyValue('--cy')) / 100;
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    field.scale.x = camera.aspect;
    if (working) {
      density = Math.min(devicePixelRatio, 1.75);
      renderer.setPixelRatio(density);
      renderer.setSize(width, height, false);
      field.material.uniforms.density.value = density;
    }
  }
  function animate(ms) {
    if (!working) return;
    const delta = last ? Math.min((ms - last) / 1000, .05) : 0;
    last = ms;
    const t = 1 - Math.pow(.0005, delta);
    if (auto && pointers.size === 0) turn += delta;
    smoothZoom = reducedMotion ? zoom : lerp(smoothZoom, zoom, t);
    const viewHeight = 2 * camera.position.z * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
    const mobile = width <= 550;
    const span = mobile ? width * 1.13 : Math.min(width * .82, height * 1.63);
    subject.scale.setScalar((span / height) * viewHeight * smoothZoom);
    subject.position.x = (centerX - .5) * viewHeight * camera.aspect;
    subject.position.y = (.5 - centerY) * viewHeight;
    subject.rotation.x = lerp(subject.rotation.x, pitch + Math.sin(turn * .26) * .09, t);
    subject.rotation.y = lerp(subject.rotation.y, yaw + Math.sin(turn * .32) * .115, t);
    subject.rotation.z = lerp(subject.rotation.z, spin, t);
    field.material.uniforms.time.value = reducedMotion ? 0 : ms / 1000;
    for (const [url, model] of models) {
      if (!model) continue;
      model.fade = reducedMotion ? Number(url === displayedAsset) : lerp(model.fade, Number(url === displayedAsset), t * .65);
      model.group.visible = model.fade > .004;
      model.mesh.material.uniforms.fade.value = model.fade;
      model.points.material.uniforms.opacity.value = model.fade;
      model.points.material.uniforms.time.value = reducedMotion ? 0 : ms / 1000;
      model.points.material.uniforms.density.value = density;
    }
    renderer.render(scene, camera);
    frame = requestAnimationFrame(animate);
  }
  function setGalaxy(url) {
    asset = url;
    if (!working) { fallImage.src = url; return; }
    if (models.has(url)) {
      if (models.get(url)) displayedAsset = url;
      return;
    }
    models.set(url, null);
    loader.load(url, (texture) => {
      if (!working) { texture.dispose(); return; }
      const model = makeGalaxy(texture);
      subject.add(model.group);
      models.set(url, model);
      if (asset === url) displayedAsset = url;
    }, undefined, () => {
      models.delete(url);
      if (asset === url) fallback();
    });
  }
  function setZoom(value) {
    zoom = clamp(value, .6, 2.3);
    onZoom(zoom);
    if (!working) updateFallback();
  }
  const pointDistance = () => {
    const [a, b] = pointers.values();
    return Math.hypot(a.x - b.x, a.y - b.y);
  };
  element.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || pointers.size >= 2) return;
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    element.setPointerCapture(e.pointerId);
    if (pointers.size === 2) pinch = pointDistance();
  });
  element.addEventListener('pointermove', (e) => {
    const old = pointers.get(e.pointerId);
    if (!old) return;
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.size === 2) {
      const distance = pointDistance();
      if (pinch > 0 && distance > 0) setZoom(zoom * distance / pinch);
      pinch = distance;
    } else {
      yaw = clamp(yaw + (e.clientX - old.x) * .005, -1.04, 1.04);
      pitch = clamp(pitch + (e.clientY - old.y) * .005, -.8, .8);
      spin = clamp(spin + (e.clientX - old.x) * .0015, -.55, .55);
      if (!working) updateFallback();
    }
  });
  for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) {
    element.addEventListener(type, (e) => { pointers.delete(e.pointerId); pinch = 0; });
  }
  element.addEventListener('wheel', (e) => {
    if (e.ctrlKey || (width <= 550 && !e.shiftKey)) return;
    e.preventDefault();
    const unit = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? height : 1;
    setZoom(zoom * Math.exp(-e.deltaY * unit * .0013));
  }, { passive: false });

  if (working) {
    renderer.domElement.setAttribute('aria-hidden', 'true');
    renderer.domElement.addEventListener('webglcontextlost', (e) => { e.preventDefault(); fallback(); });
    element.append(renderer.domElement);
    resize();
    frame = requestAnimationFrame(animate);
  } else fallback();
  new ResizeObserver(resize).observe(element);

  return {
    setGalaxy,
    resize,
    zoomBy: (factor) => setZoom(zoom * factor),
    reset() { pitch = yaw = spin = turn = 0; setZoom(1); },
    get auto() { return auto; },
    set auto(value) { auto = working && value; },
  };
}
