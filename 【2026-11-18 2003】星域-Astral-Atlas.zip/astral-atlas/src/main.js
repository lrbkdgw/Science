import '@fontsource/space-grotesk/latin-400.css';
import '@fontsource/space-grotesk/latin-500.css';
import '@fontsource/space-grotesk/latin-600.css';
import '@fontsource/ibm-plex-mono/latin-400.css';
import '@fontsource/ibm-plex-mono/latin-500.css';
import '@fontsource-variable/noto-sans-sc';
import './style.css';
import { createViewer } from './galaxy.js';

const icons = import.meta.glob('/node_modules/lucide-static/icons/{arrow-up-right,box,chevron-left,chevron-right,circle-help,maximize,minimize,minus,mouse,move,pause,play,plus,rotate-ccw,scan-line,telescope,volume-2,volume-x,x}.svg', { eager: true, query: '?raw', import: 'default' });
const icon = (name) => icons[`/node_modules/lucide-static/icons/${name}.svg`] ?? '';
function hydrateIcons(parent = document) {
  parent.querySelectorAll('[data-icon]').forEach((item) => {
    item.innerHTML = icon(item.dataset.icon);
    item.setAttribute('aria-hidden', 'true');
  });
}
function changeIcon(button, name) {
  button.querySelector('i').innerHTML = icon(name);
}
function buttonLabel(button, label) {
  button.setAttribute('aria-label', label);
  button.title = label;
}

const galaxies = [
  { name: '银河系', en: 'MILKY WAY', catalog: 'GALACTIC CENTER', type: '棒旋星系', size: '约 10 万光年', ra: '17h 45m', dec: '−29° 00′', image: '/milky-way.jpg' },
  { name: '仙女座星系', en: 'ANDROMEDA', catalog: 'MESSIER 31', type: '旋涡星系', size: '约 15 万光年', ra: '00h 42m', dec: '+41° 16′', image: '/andromeda.jpg' },
  { name: '涡状星系', en: 'WHIRLPOOL', catalog: 'MESSIER 51', type: '旋涡星系', size: '约 8 万光年', ra: '13h 29m', dec: '+47° 12′', image: '/whirlpool.jpg' },
];

const get = (id) => document.getElementById(id);
const text = (id, content) => { get(id).textContent = content; };
const numbering = (value) => String(value).padStart(2, '0');
const total = numbering(galaxies.length);
const rotation = get('rotation');
const zoomIn = get('zoom-in');
const zoomOut = get('zoom-out');
const panel = get('panel');
const panelContent = get('panel-content');
let selection = 0;
let fallbackActive = false;

hydrateIcons();
const viewer = createViewer(get('sky'), (value) => {
  text('zoom-level', `${Math.round(value * 100)}%`);
  zoomIn.disabled = value >= 2.3;
  zoomOut.disabled = value <= .6;
}, () => {
  fallbackActive = true;
  text('engine-label', '2D FALLBACK');
  text('system-status', '静态图像模式');
  rotation.disabled = true;
  changeIcon(rotation, 'play');
  rotation.setAttribute('aria-pressed', 'false');
  buttonLabel(rotation, '静态模式下不支持自动旋转');
});

const steps = galaxies.map((galaxy, i) => {
  const button = document.createElement('button');
  buttonLabel(button, `观测${galaxy.name}`);
  button.addEventListener('click', () => selectGalaxy(i));
  get('steps').append(button);
  return button;
});

function selectGalaxy(index) {
  selection = (index + galaxies.length) % galaxies.length;
  const galaxy = galaxies[selection];
  const number = numbering(selection + 1);
  viewer.setGalaxy(galaxy.image);
  viewer.reset();
  text('galaxy-name', galaxy.name);
  text('galaxy-en', galaxy.en);
  text('reticle-name', galaxy.en);
  text('catalog', galaxy.catalog);
  text('galaxy-type', galaxy.type);
  text('galaxy-size', galaxy.size);
  text('card-index', `${number} / ${total}`);
  text('target-index', number);
  text('coordinates', `RA ${galaxy.ra}   DEC ${galaxy.dec}`);
  get('card-image').style.setProperty('--card-image', `url('${galaxy.image}')`);
  steps.forEach((button, i) => {
    button.classList.toggle('selected', i === selection);
    button.setAttribute('aria-pressed', String(i === selection));
  });
}
function syncRotation() {
  if (fallbackActive) return;
  const auto = viewer.auto;
  rotation.setAttribute('aria-pressed', String(auto));
  changeIcon(rotation, auto ? 'pause' : 'play');
  buttonLabel(rotation, auto ? '暂停旋转' : '开启自动旋转');
}
get('previous').addEventListener('click', () => selectGalaxy(selection - 1));
get('next').addEventListener('click', () => selectGalaxy(selection + 1));
zoomIn.addEventListener('click', () => viewer.zoomBy(1.2));
zoomOut.addEventListener('click', () => viewer.zoomBy(1 / 1.2));
get('reset').addEventListener('click', () => viewer.reset());
rotation.addEventListener('click', () => { viewer.auto = !viewer.auto; syncRotation(); });
selectGalaxy(0);
syncRotation();

const touch = matchMedia('(pointer: coarse)');
function updateHints() {
  text('drag-hint', touch.matches ? '滑动旋转' : '拖动旋转');
  text('zoom-hint', touch.matches ? '双指缩放' : '滚轮缩放');
}
touch.addEventListener('change', updateHints);
updateHints();

const immersive = get('immersive');
function setImmersive(active) {
  document.body.classList.toggle('immersive-mode', active);
  viewer.resize();
  immersive.setAttribute('aria-pressed', String(active));
  changeIcon(immersive, active ? 'minimize' : 'maximize');
  immersive.querySelector('span').textContent = active ? '退出沉浸' : '沉浸模式';
  buttonLabel(immersive, active ? '退出沉浸模式' : '沉浸模式');
}
setImmersive(false);
immersive.addEventListener('click', () => setImmersive(!document.body.classList.contains('immersive-mode')));

const panels = {
  atlas: ['GALAXY ATLAS', '星系图鉴'],
  guide: ['FLIGHT MANUAL', '操作指南'],
  about: ['ABOUT ASTRAL ATLAS', '关于星域'],
};
let activePanel;
function syncNav(name) {
  document.querySelectorAll('.nav-link').forEach((button) => {
    const current = button.dataset.panel === name;
    button.classList.toggle('current', current);
    if (current) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  });
}
function openPanel(name) {
  if (name === 'explore') { setImmersive(false); return; }
  activePanel = name;
  const [eyebrow, title] = panels[name];
  text('panel-eyebrow', eyebrow);
  text('panel-title', title);
  if (name === 'atlas') {
    panelContent.innerHTML = `<p>选择一座星系，前往观测。</p><div class="atlas-grid">${galaxies.map((galaxy, i) => `
      <button class="atlas-item ${i === selection ? 'selected' : ''}" data-index="${i}">
        <img src="${galaxy.image}" alt=""><span>${galaxy.name}</span><small>${galaxy.en}</small>
      </button>`).join('')}</div>`;
  } else if (name === 'guide') {
    panelContent.innerHTML = `<ul class="guide-list">
      <li><i data-icon="move"></i> 拖动星系旋转视角；触屏上左右滑动。</li>
      <li><i data-icon="mouse"></i> 滚轮、双指开合或 + / − 按钮可缩放。</li>
      <li><i data-icon="chevron-right"></i> 使用左右方向键或「星系导航」切换目标。</li>
      <li><i data-icon="rotate-ccw"></i> 点击重置按钮，或按 0 返回初始视角。</li>
    </ul>`;
  } else {
    panelContent.innerHTML = '<p>星域是一座用 Three.js 构建的互动宇宙观测站。你可以在银河系、仙女座星系与涡状星系之间切换，旋转星盘，近看星尘与旋臂。</p><p>星系画面为艺术示意，并非实时望远镜影像。坐标与直径仅供科普参考。</p>';
  }
  hydrateIcons(panelContent);
  syncNav(name === 'guide' ? 'explore' : name);
  panel.showModal();
}
document.querySelectorAll('[data-panel]').forEach((button) => button.addEventListener('click', () => openPanel(button.dataset.panel)));
document.querySelector('.brand').addEventListener('click', (event) => { event.preventDefault(); setImmersive(false); window.scrollTo(0, 0); });
get('close-panel').addEventListener('click', () => panel.close());
panel.addEventListener('click', (event) => { if (event.target === panel) panel.close(); });
panel.addEventListener('close', () => { activePanel = undefined; syncNav('explore'); });
panelContent.addEventListener('click', (event) => {
  const button = event.target.closest('button[data-index]');
  if (!button || activePanel !== 'atlas') return;
  selectGalaxy(Number(button.dataset.index));
  panel.close();
});

const audioButton = get('audio');
let audioContext, master, soundOn = false, audioPending = false;
function makeSound() {
  const Context = window.AudioContext || window.webkitAudioContext;
  audioContext = new Context();
  master = audioContext.createGain();
  master.gain.value = 0;
  master.connect(audioContext.destination);
  for (const [index, hz] of [55, 82.41, 110, 130.81, 164.81, 195.99].entries()) {
    const oscillator = audioContext.createOscillator();
    const breath = audioContext.createOscillator();
    const voice = audioContext.createGain();
    const depth = audioContext.createGain();
    oscillator.type = index === 0 ? 'triangle' : 'sine';
    oscillator.frequency.value = hz;
    oscillator.detune.value = index % 2 === 0 ? -2 : 2;
    voice.gain.value = .042 / (1 + index * .23);
    breath.frequency.value = .065 + index * .009;
    depth.gain.value = voice.gain.value * .7;
    breath.connect(depth).connect(voice.gain);
    oscillator.connect(voice).connect(master);
    breath.start();
    oscillator.start();
  }
}
audioButton.addEventListener('click', async () => {
  if (audioPending) return;
  audioPending = true;
  try {
    if (!audioContext) makeSound();
    if (!soundOn) await audioContext.resume();
    soundOn = !soundOn;
    master.gain.setTargetAtTime(soundOn ? .57 : 0, audioContext.currentTime, .25);
    audioButton.setAttribute('aria-pressed', String(soundOn));
    changeIcon(audioButton, soundOn ? 'volume-2' : 'volume-x');
    buttonLabel(audioButton, soundOn ? '关闭环境音' : '开启环境音');
  } catch {
    buttonLabel(audioButton, '当前浏览器无法播放环境音');
  } finally { audioPending = false; }
});

window.addEventListener('keydown', (event) => {
  if (panel.open || event.metaKey || event.ctrlKey || event.altKey || event.defaultPrevented) return;
  const immersed = document.body.classList.contains('immersive-mode');
  switch (event.key) {
    case 'ArrowLeft': if (immersed) return; selectGalaxy(selection - 1); break;
    case 'ArrowRight': if (immersed) return; selectGalaxy(selection + 1); break;
    case '+': case '=': viewer.zoomBy(1.2); break;
    case '-': viewer.zoomBy(1 / 1.2); break;
    case '0': viewer.reset(); break;
    case 'Escape': if (!immersed) return; setImmersive(false); break;
    default: return;
  }
  event.preventDefault();
});
