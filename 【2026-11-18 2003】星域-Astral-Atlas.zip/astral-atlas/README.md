# 星域 · Astral Atlas

这是源码目录。若仅用于体验，请直接双击压缩包根目录的 `星域.html`，无需运行任何命令。

## 开发与构建

维护源码需要 Node.js 20.19+ 或 22.12+。首次安装构建工具需要网络，生成的离线 HTML 不需要网络或依赖安装。

```sh
npm ci
npm run dev           # 开发预览
npm run build         # 构建常规 Web 版本到 dist/
npm run build:offline # 构建单文件离线版本到 dist/offline/星域.html
```

星盘由艺术示意纹理与具有三维深度的粒子组成，并非望远镜实拍或科学模拟。WebGL 2 不可用时，页面自动切换到可缩放的静态图像。
