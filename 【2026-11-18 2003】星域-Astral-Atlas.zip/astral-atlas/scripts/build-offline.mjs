import { readFileSync, mkdirSync, writeFileSync } from 'node:fs';
import { basename, dirname, extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

// Run after Vite's production build. Package the page for file:// as well as HTTP.
const root = fileURLToPath(new URL('../', import.meta.url));
const dist = join(root, 'dist');
const output = join(dist, 'offline', '星域.html');
const read = (file) => readFileSync(join(dist, file), 'utf8');
const mimeTypes = { '.svg': 'image/svg+xml', '.jpg': 'image/jpeg', '.woff2': 'font/woff2' };
const cache = new Map();
function embed(path) {
  if (!cache.has(path)) {
    const mime = mimeTypes[extname(path)];
    if (!path.startsWith('/') || !mime) throw new Error(`Unsupported offline asset: ${path}`);
    const payload = readFileSync(join(dist, path.slice(1))).toString('base64');
    cache.set(path, `data:${mime};base64,${payload}`);
  }
  return cache.get(path);
}

const html = read('index.html');
const scriptTag = /<script\b[^>]*\bsrc="(\/[^"\n]+\.js)"[^>]*><\/script>/;
const styleTag = /<link\b[^>]*\brel="stylesheet"[^>]*\bhref="(\/[^"\n]+\.css)"[^>]*>/;
const [, jsPath] = html.match(scriptTag) ?? [];
const [, cssPath] = html.match(styleTag) ?? [];
if (!jsPath || !cssPath) throw new Error('Vite entry files not found');
const js = read(jsPath);
const codepoints = [...new Set(Array.from(html + js, (char) => char.codePointAt(0)))];
function usedFontFace(rule) {
  const ranges = rule.match(/unicode-range:([^;}]+)/i)?.[1];
  return !ranges || ranges.split(',').some((range) => {
    const [first, last] = range.trim().slice(2).split('-');
    const lo = parseInt(first.replaceAll('?', '0'), 16);
    const hi = parseInt(last ?? first.replaceAll('?', 'F'), 16);
    return codepoints.some((code) => code >= lo && code <= hi);
  });
}
const css = read(cssPath)
  .replace(/@font-face\{[^}]*\}/g, (rule) => usedFontFace(rule) ? rule.replace(/,url\([^)]*\.woff\)format\([^)]+\)/g, '') : '')
  .replace(/url\(["']?(\/[^"')]+)["']?\)/g, (_, path) => `url("${embed(path)}")`);
const inlineJS = js
  .replace(/(["'`])(\/[a-z-]+\.jpg)\1/g, (_, quote, path) => `${quote}${embed(path)}${quote}`)
  .replace(/<\/script/gi, '<\\/script');
const licenses = ['three', 'lucide-static', '@fontsource/space-grotesk', '@fontsource/ibm-plex-mono', '@fontsource-variable/noto-sans-sc']
  .map((pkg) => `${pkg}\n${readFileSync(join(root, 'node_modules', pkg, 'LICENSE'), 'utf8')}`)
  .join('\n\n').replaceAll('-->', '-- >');
const csp = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; font-src data:">`;
const page = html
  .replace('<meta charset="UTF-8">', (tag) => `${tag}\n    ${csp}`)
  .replace(scriptTag, '')
  .replace(styleTag, () => `<style>${css}</style>`)
  .replace(/(href|src)="(\/mark\.svg)"/g, (_, key, path) => `${key}="${embed(path)}"`)
  .replace('</body>', () => `<script type="module">\n${inlineJS}\n</script>\n</body>`)
  .replace('</html>', () => `<!-- Bundled third-party licenses\n${licenses}\n-->\n</html>`);

mkdirSync(dirname(output), { recursive: true });
writeFileSync(output, page);
console.log(`Offline page: dist/offline/${basename(output)} (${Math.round(Buffer.byteLength(page) / 1024)} KiB)`);
