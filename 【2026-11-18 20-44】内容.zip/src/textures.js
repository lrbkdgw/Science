import * as THREE from 'three';

const TAU = Math.PI * 2;

/* ---------------------------------------------------------------- noise */

function hash(x, y, seed) {
  const n = Math.sin(x * 127.1 + y * 311.7 + seed * 43.7) * 43758.5453;
  return n - Math.floor(n);
}

function valueNoise(x, y, seed) {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const xf = x - xi;
  const yf = y - yi;
  const u = xf * xf * (3 - 2 * xf);
  const v = yf * yf * (3 - 2 * yf);

  const a = hash(xi, yi, seed);
  const b = hash(xi + 1, yi, seed);
  const c = hash(xi, yi + 1, seed);
  const d = hash(xi + 1, yi + 1, seed);

  return a * (1 - u) * (1 - v) + b * u * (1 - v) + c * (1 - u) * v + d * u * v;
}

function fbm(x, y, seed, octaves) {
  let sum = 0;
  let amp = 0.5;
  let freq = 1;
  let norm = 0;
  for (let i = 0; i < octaves; i += 1) {
    sum += amp * valueNoise(x * freq, y * freq, seed + i * 17.3);
    norm += amp;
    freq *= 2.03;
    amp *= 0.5;
  }
  return sum / norm;
}

/* -------------------------------------------------------------- textures */

function makeCanvas(size) {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  return canvas;
}

/** 中心向外的柔和圆形辉光（核心、星云底座） */
export function createGlowTexture(size = 256, falloff = 2.8) {
  const canvas = makeCanvas(size);
  const ctx = canvas.getContext('2d');
  const img = ctx.createImageData(size, size);
  const half = size / 2;

  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const dx = (x - half + 0.5) / half;
      const dy = (y - half + 0.5) / half;
      const d = Math.min(1, Math.sqrt(dx * dx + dy * dy));
      const a = Math.pow(1 - d, falloff);
      const i = (y * size + x) * 4;
      img.data[i] = 255;
      img.data[i + 1] = 255;
      img.data[i + 2] = 255;
      img.data[i + 3] = Math.round(a * 255);
    }
  }

  ctx.putImageData(img, 0, 0);
  const texture = new THREE.CanvasTexture(canvas);
  texture.minFilter = THREE.LinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.needsUpdate = true;
  return texture;
}

/** 星云：分形噪声 + 丝状结构 + 径向羽化 */
export function createNebulaTexture(seed = 1, size = 256) {
  const canvas = makeCanvas(size);
  const ctx = canvas.getContext('2d');
  const img = ctx.createImageData(size, size);

  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const u = (x / size) * 2 - 1;
      const v = (y / size) * 2 - 1;
      const d = Math.min(1.4, Math.sqrt(u * u + v * v));

      const nx = u * 2.4 + seed * 9.7;
      const ny = v * 2.4 + seed * 5.3;
      const base = fbm(nx, ny, seed, 5);
      const detail = fbm(nx * 3.1 + 11.0, ny * 3.1 - 7.0, seed + 9, 4);
      const ridge = 1 - Math.abs(base * 2 - 1);

      let value = base * 0.62 + detail * 0.3 + ridge * 0.36 - 0.28;
      value = Math.max(0, value);
      value = Math.pow(value, 1.9);

      const mask = Math.pow(Math.max(0, 1 - d), 2.6);
      const alpha = Math.min(1, value * mask * 2.6);

      // 让云气内部带一点冷暖变化
      const warm = Math.pow(Math.max(0, base - 0.45), 1.5) * 1.8;
      const i = (y * size + x) * 4;
      img.data[i] = 255;
      img.data[i + 1] = Math.round(255 * (0.72 + warm * 0.28));
      img.data[i + 2] = Math.round(255 * (0.62 + (1 - base) * 0.38));
      img.data[i + 3] = Math.round(alpha * 255);
    }
  }

  ctx.putImageData(img, 0, 0);
  const texture = new THREE.CanvasTexture(canvas);
  texture.minFilter = THREE.LinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.needsUpdate = true;
  return texture;
}

/** 亮星的十字星芒 */
export function createFlareTexture(size = 256) {
  const canvas = makeCanvas(size);
  const ctx = canvas.getContext('2d');
  const img = ctx.createImageData(size, size);
  const half = size / 2;

  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const u = (x - half + 0.5) / half;
      const v = (y - half + 0.5) / half;
      const d = Math.min(1, Math.sqrt(u * u + v * v));
      const ax = Math.abs(u);
      const ay = Math.abs(v);

      const glow = Math.pow(1 - d, 3.2);
      const spikes =
        Math.exp(-ay * ay * 700) * Math.exp(-ax * 2.6) * 0.9 +
        Math.exp(-ax * ax * 700) * Math.exp(-ay * 2.6) * 0.9;

      const a = Math.min(1, glow * 0.9 + spikes * 0.6);
      const i = (y * size + x) * 4;
      img.data[i] = 255;
      img.data[i + 1] = 255;
      img.data[i + 2] = 255;
      img.data[i + 3] = Math.round(a * 255);
    }
  }

  ctx.putImageData(img, 0, 0);
  const texture = new THREE.CanvasTexture(canvas);
  texture.minFilter = THREE.LinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.needsUpdate = true;
  return texture;
}

export { TAU };

/* --------------------------------------------------------- galaxy haze */

const HAZE_STOPS = [
  [0.0, [255, 244, 220]],
  [0.24, [255, 210, 154]],
  [0.48, [255, 128, 186]],
  [0.74, [150, 116, 255]],
  [1.0, [72, 200, 255]],
];

function hazeColor(t, out) {
  const c = Math.min(1, Math.max(0, t));
  for (let i = 0; i < HAZE_STOPS.length - 1; i += 1) {
    const [ta, ca] = HAZE_STOPS[i];
    const [tb, cb] = HAZE_STOPS[i + 1];
    if (c <= tb) {
      const k = (c - ta) / (tb - ta);
      out[0] = ca[0] + (cb[0] - ca[0]) * k;
      out[1] = ca[1] + (cb[1] - ca[1]) * k;
      out[2] = ca[2] + (cb[2] - ca[2]) * k;
      return out;
    }
  }
  return out;
}

const smoothstep = (a, b, x) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};

/**
 * 旋臂雾气贴图：把对数螺旋的密度场烘焙成一张图，
 * 再作为一大片 additive 平面铺在星系盘面上，让旋臂看起来有「云气」而不是散点。
 */
export function createGalaxyHazeTexture({
  size = 384,
  radius = 46,
  arms = 4,
  seed = 4.2,
} = {}) {
  const canvas = makeCanvas(size);
  const ctx = canvas.getContext('2d');
  const img = ctx.createImageData(size, size);
  const rgb = [0, 0, 0];
  const half = size / 2;
  const worldScale = (radius * 1.18) / half;

  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const u = (x - half + 0.5) / half;
      const v = (y - half + 0.5) / half;

      const rw = Math.sqrt(u * u + v * v) * half * worldScale;
      const t = rw / radius;
      const theta = Math.atan2(v, u);

      // 对数螺旋相位
      const phase = theta - 2.85 * Math.log(1 + rw * 0.13);
      const armPattern = Math.pow(0.5 + 0.5 * Math.cos(phase * arms), 2.4);

      const n1 = fbm(u * 3.1 + seed, v * 3.1 - seed * 0.7, seed, 4);
      const n2 = fbm(u * 7.6 - seed * 1.3, v * 7.6 + seed * 0.4, seed + 5, 3);
      const turb = 0.5 + 0.8 * n1 + 0.35 * n2;

      const edge = smoothstep(1.06, 0.78, t);
      const core = 0.9 * Math.exp(-Math.pow(t / 0.15, 2));
      const armsMask = armPattern * smoothstep(0.02, 0.16, t) * edge;

      let density = (armsMask * 0.9 + 0.1 * edge) * turb + core;
      density = Math.max(0, density - 0.08);

      const alpha = Math.min(1, Math.pow(density, 1.25) * 0.7);
      hazeColor(t, rgb);

      const i = (y * size + x) * 4;
      img.data[i] = rgb[0];
      img.data[i + 1] = rgb[1];
      img.data[i + 2] = rgb[2];
      img.data[i + 3] = Math.round(alpha * 255);
    }
  }

  ctx.putImageData(img, 0, 0);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.minFilter = THREE.LinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.needsUpdate = true;
  return texture;
}
