import * as THREE from 'three';
import {
  galaxyVertexShader,
  starfieldVertexShader,
  pointFragmentShader,
} from './shaders.js';
import {
  createGlowTexture,
  createNebulaTexture,
  createGalaxyHazeTexture,
  createFlareTexture,
} from './textures.js';

const TAU = Math.PI * 2;

const PALETTE = [
  { t: 0.0, color: new THREE.Color('#ffe6b4') },
  { t: 0.24, color: new THREE.Color('#ffb173') },
  { t: 0.48, color: new THREE.Color('#ff86bd') },
  { t: 0.74, color: new THREE.Color('#9b78ff') },
  { t: 1.0, color: new THREE.Color('#4cc9ff') },
];

const HOT_STAR = new THREE.Color('#d9e9ff');

function gaussian() {
  let u = 0;
  let v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(TAU * v);
}

function colorAt(t, target) {
  const clamped = Math.min(1, Math.max(0, t));
  for (let i = 0; i < PALETTE.length - 1; i += 1) {
    const a = PALETTE[i];
    const b = PALETTE[i + 1];
    if (clamped <= b.t) {
      const k = (clamped - a.t) / (b.t - a.t);
      return target.copy(a.color).lerp(b.color, k);
    }
  }
  return target.copy(PALETTE[PALETTE.length - 1].color);
}

export function createGalaxy({
  count = 180000,
  radius = 46,
  arms = 4,
  pixelRatio = 1.5,
} = {}) {
  const group = new THREE.Group();
  const spin = new THREE.Group();
  group.add(spin);

  const positions = new Float32Array(count * 3);
  const colors = new Float32Array(count * 3);
  const sizes = new Float32Array(count);
  const seeds = new Float32Array(count);
  const scratch = new THREE.Color();

  for (let i = 0; i < count; i += 1) {
    const kind = Math.random();
    let x;
    let y;
    let z;
    let brightness = 1;

    if (kind < 0.055) {
      /* --- 核球：密集、温暖、略厚 --- */
      const r = Math.abs(gaussian()) * 4.2;
      const angle = Math.random() * TAU;
      x = Math.cos(angle) * r + gaussian() * 0.4;
      z = Math.sin(angle) * r + gaussian() * 0.4;
      y = gaussian() * (0.5 + 2.3 * Math.exp(-r * 0.2));
      brightness = 0.85;
    } else if (kind < 0.125) {
      /* --- 弥散星晕：稀薄、偏暗 --- */
      const r = (0.12 + Math.pow(Math.random(), 0.6) * 0.95) * radius;
      const angle = Math.random() * TAU;
      x = Math.cos(angle) * r + gaussian() * 1.4;
      z = Math.sin(angle) * r + gaussian() * 1.4;
      y = gaussian() * (1.1 + r * 0.05);
      brightness = 0.5;
    } else {
      /* --- 旋臂：对数螺旋 + 高斯抖动 --- */
      const arm = Math.floor(Math.random() * arms);
      const t = Math.pow(Math.random(), 1.42);
      const r = 3.0 + t * (radius - 3.0);
      const armAngle = (arm / arms) * TAU;
      const theta =
        armAngle +
        2.85 * Math.log(1 + r * 0.13) +
        gaussian() * 0.105 * (0.5 + r / radius);

      const spread = 0.38 + r * 0.04;
      x = Math.cos(theta) * r + gaussian() * spread;
      z = Math.sin(theta) * r + gaussian() * spread;
      y = gaussian() * (0.3 + Math.pow(r / radius, 1.7) * 0.5);
      brightness = 1.0;
    }

    const p = i * 3;
    positions[p] = x;
    positions[p + 1] = y;
    positions[p + 2] = z;

    const radial = Math.min(1, Math.sqrt(x * x + z * z) / radius);
    colorAt(radial, scratch);

    // 少量炽热的蓝白巨星
    if (Math.random() < 0.035) {
      scratch.copy(HOT_STAR);
      brightness *= 1.55;
    }

    const shade = (0.9 + Math.random() * 0.72) * brightness;
    colors[p] = scratch.r * shade;
    colors[p + 1] = scratch.g * shade;
    colors[p + 2] = scratch.b * shade;

    let size = 0.55 + Math.pow(Math.random(), 2.4) * 1.9;
    if (Math.random() < 0.012) size *= 2.6;
    sizes[i] = size;
    seeds[i] = Math.random();
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('aColor', new THREE.BufferAttribute(colors, 3));
  geometry.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
  geometry.setAttribute('aSeed', new THREE.BufferAttribute(seeds, 1));

  const material = new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
      uSize: { value: 3.6 },
      uPixelRatio: { value: pixelRatio },
    },
    vertexShader: galaxyVertexShader,
    fragmentShader: pointFragmentShader,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });

  const points = new THREE.Points(geometry, material);
  points.frustumCulled = false;
  spin.add(points);

  /* ------------------------------------------------------ 旋臂云气平面 */

  const hazeTexture = createGalaxyHazeTexture({ size: 384, radius, arms });
  const hazeSize = radius * 2.36;
  const haze = new THREE.Mesh(
    new THREE.PlaneGeometry(hazeSize, hazeSize),
    new THREE.MeshBasicMaterial({
      map: hazeTexture,
      transparent: true,
      opacity: 0.4,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    }),
  );
  haze.rotation.x = -Math.PI / 2;
  spin.add(haze);

  /* ---------------------------------------------------------- 核心辉光 */

  const glowTexture = createGlowTexture(256, 2.4);

  const makeGlow = (color, scale, opacity) => {
    const sprite = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: glowTexture,
        color: new THREE.Color(color),
        transparent: true,
        opacity,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        depthTest: false,
      }),
    );
    sprite.scale.set(scale, scale, 1);
    sprite.renderOrder = 2;
    return sprite;
  };

  // 几颗带十字星芒的亮星，为旋臂增添一点闪烁的细节
  const flareTexture = createFlareTexture(128);
  const flares = [];
  for (let i = 0; i < 6; i += 1) {
    const angle = Math.random() * TAU;
    const r = 14 + Math.random() * 28;
    const sprite = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: flareTexture,
        color: new THREE.Color(i % 3 === 0 ? '#ffe3b8' : '#d6e8ff'),
        transparent: true,
        opacity: 0.3 + Math.random() * 0.2,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        depthTest: false,
      }),
    );
    const scale = 1.4 + Math.random() * 1.8;
    sprite.scale.set(scale, scale, 1);
    sprite.position.set(
      Math.cos(angle) * r,
      (Math.random() - 0.5) * 3,
      Math.sin(angle) * r,
    );
    sprite.userData.baseOpacity = sprite.material.opacity;
    sprite.userData.phase = Math.random() * TAU;
    flares.push(sprite);
    spin.add(sprite);
  }

  const outerHalo = makeGlow('#ff9a63', 48, 0.05);
  const midHalo = makeGlow('#ffbd7e', 20, 0.09);
  const coreGlow = makeGlow('#ffe9c4', 6.5, 0.32);
  spin.add(outerHalo, midHalo, coreGlow);

  /* ------------------------------------------------------------ 星云 */

  const nebulaTextures = [
    createNebulaTexture(2.7, 256),
    createNebulaTexture(7.9, 256),
  ];
  const nebulaColors = ['#8a5cff', '#ff5fa8', '#3fd0ff', '#7d74ff', '#ff9b5e'];
  const nebulae = [];

  for (let i = 0; i < 11; i += 1) {
    const baseOpacity = 0.045 + Math.random() * 0.065;
    const sprite = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: nebulaTextures[i % nebulaTextures.length],
        color: new THREE.Color(nebulaColors[i % nebulaColors.length]),
        transparent: true,
        opacity: baseOpacity,
        rotation: Math.random() * TAU,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        depthTest: true,
      }),
    );

    const r = 10 + Math.random() * 58;
    const angle = Math.random() * TAU;
    sprite.position.set(
      Math.cos(angle) * r,
      (Math.random() - 0.5) * 14,
      Math.sin(angle) * r,
    );

    const scale = 34 + Math.random() * 52;
    sprite.scale.set(scale, scale * (0.65 + Math.random() * 0.7), 1);
    sprite.userData.baseOpacity = baseOpacity;
    sprite.userData.phase = Math.random() * TAU;
    sprite.userData.speed = 0.1 + Math.random() * 0.18;

    nebulae.push(sprite);
    group.add(sprite);
  }

  /* 两团远处的深空星云，为画面提供纵深 */
  for (let i = 0; i < 2; i += 1) {
    const baseOpacity = 0.045;
    const sprite = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: nebulaTextures[1],
        color: new THREE.Color(i === 0 ? '#4c3cff' : '#ff4f9a'),
        transparent: true,
        opacity: baseOpacity,
        rotation: Math.random() * TAU,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    );
    sprite.position.set(
      (i === 0 ? -1 : 1) * (100 + Math.random() * 40),
      (Math.random() - 0.5) * 100,
      -260 - Math.random() * 120,
    );
    sprite.scale.set(360, 270, 1);
    sprite.userData.baseOpacity = baseOpacity;
    sprite.userData.phase = Math.random() * TAU;
    sprite.userData.speed = 0.06;
    nebulae.push(sprite);
    group.add(sprite);
  }

  return { group, spin, material, nebulae, points, haze, flares };
}

/* -------------------------------------------------------------- 星空 */

export function createStarfield({
  pixelRatio = 1.5,
  farCount = 6500,
  nearCount = 2500,
} = {}) {
  const root = new THREE.Group();

  const starColors = ['#ffffff', '#e8f1ff', '#c3d8ff', '#ffe9c9', '#ffd3a1', '#d8c8ff'];

  const makeLayer = (count, minRadius, maxRadius, uSize, brightness) => {
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const sizes = new Float32Array(count);
    const seeds = new Float32Array(count);
    const color = new THREE.Color();

    for (let i = 0; i < count; i += 1) {
      // 球壳内均匀分布
      const u = Math.random() * 2 - 1;
      const phi = Math.random() * TAU;
      const s = Math.sqrt(1 - u * u);
      const r = minRadius + Math.random() * (maxRadius - minRadius);

      const p = i * 3;
      positions[p] = Math.cos(phi) * s * r;
      positions[p + 1] = u * r;
      positions[p + 2] = Math.sin(phi) * s * r;

      color.set(starColors[Math.floor(Math.random() * starColors.length)]);
      const shade = brightness * (0.45 + Math.random() * 0.75);
      colors[p] = color.r * shade;
      colors[p + 1] = color.g * shade;
      colors[p + 2] = color.b * shade;

      sizes[i] = 0.7 + Math.pow(Math.random(), 2.0) * 1.7;
      seeds[i] = Math.random();
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('aColor', new THREE.BufferAttribute(colors, 3));
    geometry.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
    geometry.setAttribute('aSeed', new THREE.BufferAttribute(seeds, 1));

    const material = new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 },
        uSize: { value: uSize },
        uPixelRatio: { value: pixelRatio },
      },
      vertexShader: starfieldVertexShader,
      fragmentShader: pointFragmentShader,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });

    const points = new THREE.Points(geometry, material);
    points.frustumCulled = false;
    root.add(points);
    return material;
  };

  const farMaterial = makeLayer(farCount, 340, 1000, 11, 0.95);
  const nearMaterial = makeLayer(nearCount, 130, 330, 3.6, 0.72);

  return { root, materials: [farMaterial, nearMaterial] };
}

/** 深空穹顶 */
export function createSky(skyShader) {
  return new THREE.Mesh(
    new THREE.SphereGeometry(1500, 48, 32),
    new THREE.ShaderMaterial({
      vertexShader: skyShader.vertexShader,
      fragmentShader: skyShader.fragmentShader,
      side: THREE.BackSide,
      depthWrite: false,
      depthTest: false,
    }),
  );
}
