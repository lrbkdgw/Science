import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';

import { createGalaxy, createStarfield, createSky } from './galaxy.js';
import { skyShader, filmShader } from './shaders.js';
import './style.css';

const clamp = (v, min, max) => Math.min(max, Math.max(min, v));
const lerp = (a, b, t) => a + (b - a) * t;
const easeInOutCubic = (t) =>
  t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

const isMobile =
  window.matchMedia('(max-width: 820px)').matches ||
  /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const HOME_DESKTOP = new THREE.Vector3(0, 56, 98);
const HOME_MOBILE = new THREE.Vector3(0, 118, 312);
const getHome = () =>
  (window.innerWidth / window.innerHeight < 0.95 ? HOME_MOBILE : HOME_DESKTOP).clone();

/* --------------------------------------------------------------- DOM */

const canvas = document.querySelector('#scene');
const loader = document.querySelector('#loader');
const loaderBar = document.querySelector('#loader-bar');
const loaderPct = document.querySelector('#loader-pct');
const btnSpin = document.querySelector('#btn-spin');
const btnReset = document.querySelector('#btn-reset');
const btnFull = document.querySelector('#btn-full');
const noWebgl = document.querySelector('#no-webgl');

const state = {
  autoRotate: true,
  ready: false,
  starCount: 0,
};

/* ------------------------------------------------------------ renderer */

let renderer;
try {
  renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: false,
    alpha: false,
    stencil: false,
    powerPreference: 'high-performance',
  });
} catch (error) {
  console.error(error);
  noWebgl?.classList.add('is-visible');
  loader?.classList.add('is-done');
  throw error;
}

const pixelRatio = Math.min(window.devicePixelRatio || 1, isMobile ? 1.5 : 1.75);
renderer.setPixelRatio(pixelRatio);
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setClearColor(0x02030a, 1);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.02;
renderer.outputColorSpace = THREE.SRGBColorSpace;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
  46,
  window.innerWidth / window.innerHeight,
  0.1,
  4000,
);
camera.position.set(155, 270, 540);

const controls = new OrbitControls(camera, canvas);
controls.target.set(0, 0, 0);
controls.enableDamping = true;
controls.dampingFactor = 0.055;
controls.enablePan = false;
controls.rotateSpeed = 0.42;
controls.zoomSpeed = 0.7;
controls.minDistance = 32;
controls.maxDistance = 340;
controls.minPolarAngle = 0.12;
controls.maxPolarAngle = Math.PI - 0.12;
controls.autoRotate = false;
controls.autoRotateSpeed = 0.7;
controls.enabled = false;

/* ------------------------------------------------------------- scene */

const sky = createSky(skyShader);
sky.renderOrder = -100;
scene.add(sky);

let galaxy = null;
let starfield = null;
let composer = null;
let bloomPass = null;
let filmPass = null;

const intro = {
  active: false,
  start: 0,
  duration: 5.2,
  from: new THREE.Vector3(155, 270, 540),
  to: getHome(),
};

const fly = {
  active: false,
  start: 0,
  duration: 1.7,
  from: new THREE.Vector3(),
  to: new THREE.Vector3(),
};

const pointer = { x: 0, y: 0, tx: 0, ty: 0 };

/* ---------------------------------------------------------- load steps */

const nextFrame = () =>
  new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function setProgress(value) {
  const v = clamp(Math.round(value), 0, 100);
  if (loaderBar) loaderBar.style.width = `${v}%`;
  if (loaderPct) loaderPct.textContent = String(v);
}

async function build() {
  setProgress(8);
  await nextFrame();

  const count = isMobile ? 95000 : 180000;
  state.starCount = count;

  galaxy = createGalaxy({ count, pixelRatio });
  scene.add(galaxy.group);
  setProgress(46);
  await nextFrame();

  starfield = createStarfield({
    pixelRatio,
    farCount: isMobile ? 4800 : 8000,
    nearCount: isMobile ? 1600 : 3000,
  });
  scene.add(starfield.root);
  setProgress(72);
  await nextFrame();

  composer = new EffectComposer(renderer);
  composer.setPixelRatio(pixelRatio);
  composer.setSize(window.innerWidth, window.innerHeight);
  composer.addPass(new RenderPass(scene, camera));

  bloomPass = new UnrealBloomPass(
    new THREE.Vector2(window.innerWidth, window.innerHeight),
    1.0,
    0.55,
    0.42,
  );
  composer.addPass(bloomPass);
  composer.addPass(new OutputPass());

  filmPass = new ShaderPass(filmShader);
  filmPass.uniforms.uResolution.value = new THREE.Vector2(
    window.innerWidth * pixelRatio,
    window.innerHeight * pixelRatio,
  );
  composer.addPass(filmPass);

  setProgress(92);
  await nextFrame();

  // 预渲染一帧，提前完成着色器编译
  composer.render(0);
  setProgress(100);
}

/* ------------------------------------------------------------- loop */

const timer = new THREE.Timer();
timer.connect(document);
let elapsed = 0;

function update(dt) {
  elapsed += dt;

  const sceneTime = prefersReducedMotion ? 0 : elapsed;

  if (galaxy) {
    galaxy.material.uniforms.uTime.value = sceneTime;
    if (!prefersReducedMotion) galaxy.spin.rotation.y += dt * 0.028;

    for (const sprite of galaxy.nebulae) {
      const { baseOpacity, phase, speed } = sprite.userData;
      sprite.material.opacity = prefersReducedMotion
        ? baseOpacity
        : baseOpacity * (0.78 + 0.22 * Math.sin(elapsed * speed + phase));
      if (!prefersReducedMotion) sprite.material.rotation += dt * 0.006;
    }

    if (galaxy.flares) {
      for (const sprite of galaxy.flares) {
        const { baseOpacity, phase } = sprite.userData;
        sprite.material.opacity = prefersReducedMotion
          ? baseOpacity
          : baseOpacity * (0.7 + 0.3 * Math.sin(elapsed * 1.3 + phase));
      }
    }
  }

  if (starfield) {
    starfield.materials.forEach((material) => {
      material.uniforms.uTime.value = sceneTime;
    });

    pointer.x = lerp(pointer.x, pointer.tx, 0.045);
    pointer.y = lerp(pointer.y, pointer.ty, 0.045);
    starfield.root.rotation.y = pointer.x * 0.075;
    starfield.root.rotation.x = pointer.y * 0.045;
  }

  if (intro.active) {
    const k = clamp((performance.now() / 1000 - intro.start) / intro.duration, 0, 1);
    const e = easeInOutCubic(k);
    camera.position.lerpVectors(intro.from, intro.to, e);
    camera.position.y += Math.sin(Math.PI * k) * 16;
    camera.lookAt(controls.target);

    if (k >= 1) {
      intro.active = false;
      camera.position.copy(intro.to);
      camera.lookAt(controls.target);
      controls.enabled = true;
      controls.autoRotate = state.autoRotate;
      controls.update();
    }
  } else if (fly.active) {
    const k = clamp((performance.now() / 1000 - fly.start) / fly.duration, 0, 1);
    const e = easeInOutCubic(k);
    camera.position.lerpVectors(fly.from, fly.to, e);
    camera.lookAt(controls.target);
    if (k >= 1) {
      fly.active = false;
      controls.enabled = true;
      controls.autoRotate = state.autoRotate;
      controls.update();
    }
  } else if (controls.enabled) {
    controls.update(dt);
  }

  if (bloomPass) {
    bloomPass.strength = prefersReducedMotion
      ? 1.0
      : 1.0 + Math.sin(elapsed * 0.42) * 0.07;
  }
  if (filmPass) filmPass.uniforms.uTime.value = elapsed;
}

function animate() {
  requestAnimationFrame(animate);
  timer.update();
  const dt = Math.min(timer.getDelta(), 0.05);
  update(dt);
  composer.render(dt);
}

/* --------------------------------------------------------------- UI */

function setAutoRotate(value) {
  state.autoRotate = value;
  if (!intro.active && !fly.active) controls.autoRotate = value;
  btnSpin?.classList.toggle('is-active', value);
  btnSpin?.setAttribute('aria-pressed', String(value));
  if (btnSpin) {
    const label = btnSpin.querySelector('.ctrl-label');
    if (label) label.textContent = value ? '自动漫游' : '手动漫游';
  }
}

function resetView() {
  if (!state.ready) return;
  intro.active = false;
  controls.enabled = false;
  controls.autoRotate = false;
  fly.from.copy(camera.position);
  fly.to.copy(getHome());
  fly.start = performance.now() / 1000;
  fly.active = true;
}

async function toggleFullscreen() {
  try {
    if (!document.fullscreenElement) {
      await document.documentElement.requestFullscreen?.();
    } else {
      await document.exitFullscreen?.();
    }
  } catch (error) {
    console.warn('Fullscreen unavailable:', error);
  }
}

btnSpin?.addEventListener('click', () => setAutoRotate(!state.autoRotate));
btnReset?.addEventListener('click', resetView);
btnFull?.addEventListener('click', toggleFullscreen);

document.addEventListener('fullscreenchange', () => {
  const label = btnFull?.querySelector('.ctrl-label');
  if (label) label.textContent = document.fullscreenElement ? '退出全屏' : '全屏';
});

// 轻触/拖拽即可跳过开场镜头
canvas.addEventListener(
  'pointerdown',
  () => {
    if (!intro.active) return;
    intro.active = false;
    camera.position.copy(intro.to);
    camera.lookAt(controls.target);
    controls.enabled = true;
    controls.autoRotate = state.autoRotate;
    controls.update();
  },
  { passive: true },
);

window.addEventListener(
  'pointermove',
  (event) => {
    pointer.tx = (event.clientX / window.innerWidth - 0.5) * 2;
    pointer.ty = (event.clientY / window.innerHeight - 0.5) * 2;
  },
  { passive: true },
);

window.addEventListener('keydown', (event) => {
  if (event.target instanceof HTMLElement && event.target.tagName === 'BUTTON') return;
  if (event.code === 'Space') {
    event.preventDefault();
    setAutoRotate(!state.autoRotate);
  } else if (event.key === 'r' || event.key === 'R') {
    resetView();
  }
});

function countUpStars() {
  const el = document.querySelector('[data-stars]');
  if (!el) return;
  const target = state.starCount;
  const start = performance.now();
  const duration = 1800;

  const tick = (now) => {
    const k = clamp((now - start) / duration, 0, 1);
    const eased = 1 - Math.pow(1 - k, 3);
    el.textContent = Math.round(target * eased).toLocaleString('en-US');
    if (k < 1) requestAnimationFrame(tick);
  };

  requestAnimationFrame(tick);
}

/* ------------------------------------------------------------ resize */

function onResize() {
  const width = window.innerWidth;
  const height = window.innerHeight;
  const ratio = Math.min(window.devicePixelRatio || 1, isMobile ? 1.5 : 1.75);

  camera.aspect = width / height;
  camera.updateProjectionMatrix();

  renderer.setPixelRatio(ratio);
  renderer.setSize(width, height);

  if (composer) {
    composer.setPixelRatio(ratio);
    composer.setSize(width, height);
  }

  if (galaxy) galaxy.material.uniforms.uPixelRatio.value = ratio;
  if (starfield) {
    starfield.materials.forEach((material) => {
      material.uniforms.uPixelRatio.value = ratio;
    });
  }

  if (filmPass) {
    filmPass.uniforms.uResolution.value.set(width * ratio, height * ratio);
  }
}

window.addEventListener('resize', onResize);

/* -------------------------------------------------------------- boot */

async function boot() {
  try {
    await build();

    controls.target.set(0, 0, 0);
    intro.to = getHome();

    if (prefersReducedMotion) {
      camera.position.copy(intro.to);
      controls.enabled = true;
    } else {
      camera.position.copy(intro.from);
    }
    camera.lookAt(controls.target);

    animate();

    await wait(550);
    loader?.classList.add('is-done');
    document.body.classList.add('is-ready');
    state.ready = true;

    if (import.meta.env.DEV) {
      window.__galaxy = { scene, camera, controls, galaxy, composer, renderer, intro, fly };
    }

    if (!prefersReducedMotion) {
      await wait(420);
      intro.start = performance.now() / 1000;
      intro.active = true;
    }

    countUpStars();
  } catch (error) {
    console.error(error);
    noWebgl?.classList.add('is-visible');
    loader?.classList.add('is-done');
  }
}

// 尊重「减少动态效果」的系统偏好
if (prefersReducedMotion) {
  setAutoRotate(false);
  controls.autoRotateSpeed = 0;
}

boot();
