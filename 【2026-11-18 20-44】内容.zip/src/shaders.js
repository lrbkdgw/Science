/**
 * 星系粒子着色器
 * - 顶点着色器负责星辰的呼吸式闪动与极轻微的径向起伏
 * - 片元着色器绘制柔和的辉光点，配合 Bloom 得到发光星尘
 */

export const galaxyVertexShader = /* glsl */ `
  uniform float uTime;
  uniform float uSize;
  uniform float uPixelRatio;

  attribute float aSize;
  attribute float aSeed;
  attribute vec3 aColor;

  varying vec3 vColor;
  varying float vTwinkle;

  void main() {
    vec3 p = position;

    // 极轻微的径向呼吸，让星尘看起来是活的
    float r = length(p.xz);
    float breathe = 1.0 + 0.006 * sin(uTime * 0.35 + r * 0.22);
    p.xz *= breathe;

    vec4 mvPosition = modelViewMatrix * vec4(p, 1.0);
    gl_Position = projectionMatrix * mvPosition;

    // 每颗星独立的呼吸式闪烁
    vTwinkle = 0.72 + 0.28 * sin(uTime * 1.6 + aSeed * 6.28318);
    vColor = aColor;

    gl_PointSize = aSize * uSize * uPixelRatio * (62.0 / max(1.0, -mvPosition.z));
    gl_PointSize = clamp(gl_PointSize, 1.0, 26.0);
  }
`;

export const starfieldVertexShader = /* glsl */ `
  uniform float uTime;
  uniform float uSize;
  uniform float uPixelRatio;

  attribute float aSize;
  attribute float aSeed;
  attribute vec3 aColor;

  varying vec3 vColor;
  varying float vTwinkle;

  void main() {
    vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
    gl_Position = projectionMatrix * mvPosition;

    vTwinkle = 0.6 + 0.4 * sin(uTime * 1.15 + aSeed * 6.28318);
    vColor = aColor;

    gl_PointSize = aSize * uSize * uPixelRatio * (62.0 / max(1.0, -mvPosition.z));
    gl_PointSize = clamp(gl_PointSize, 0.7, 30.0);
  }
`;

export const pointFragmentShader = /* glsl */ `
  varying vec3 vColor;
  varying float vTwinkle;

  void main() {
    vec2 uv = gl_PointCoord - 0.5;
    float d = length(uv) * 2.0;
    if (d > 1.0) discard;

    float halo = pow(1.0 - d, 2.6);
    float core = pow(1.0 - d, 12.0);

    vec3 color = vColor * (halo * 0.95 + core * 1.9) * vTwinkle;
    float alpha = halo * 0.95 + core * 0.45;

    gl_FragColor = vec4(color, alpha);
  }
`;

/** 深空背景：极暗的冷色渐变 + 抖动去色带 */
export const skyShader = {
  vertexShader: /* glsl */ `
    varying vec3 vDir;
    void main() {
      vDir = position;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: /* glsl */ `
    varying vec3 vDir;

    void main() {
      vec3 d = normalize(vDir);
      float h = d.y * 0.5 + 0.5;

      vec3 deep = vec3(0.0035, 0.0045, 0.014);
      vec3 mid  = vec3(0.0100, 0.0130, 0.036);
      vec3 high = vec3(0.0260, 0.0200, 0.055);

      vec3 col = mix(deep, mid, smoothstep(0.0, 0.58, h));
      col = mix(col, high, smoothstep(0.58, 1.0, h));

      // 银河方向的一抹幽紫光晕
      float halo = pow(max(0.0, dot(d, normalize(vec3(0.15, 0.32, -1.0)))), 5.0);
      col += vec3(0.075, 0.035, 0.105) * halo;

      // 轻微抖动，避免大面积渐变出现色带
      float dither = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);
      col += (dither - 0.5) * 0.0015;

      gl_FragColor = vec4(col, 1.0);
    }
  `,
};

/** 最终调色：径向色散 + 暗角 + 胶片颗粒 + 冷暖分离 */
export const filmShader = {
  uniforms: {
    tDiffuse: { value: null },
    uTime: { value: 0 },
    uResolution: { value: [1, 1] },
    uVignette: { value: 0.62 },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse;
    uniform float uTime;
    uniform vec2 uResolution;
    uniform float uVignette;
    varying vec2 vUv;

    void main() {
      vec2 uv = vUv;
      vec2 dir = uv - 0.5;
      float dist = length(dir);

      // 边缘轻微色散
      float ca = 0.0016 * dist;
      vec3 col;
      col.r = texture2D(tDiffuse, uv + dir * ca).r;
      col.g = texture2D(tDiffuse, uv).g;
      col.b = texture2D(tDiffuse, uv - dir * ca).b;

      // 暗角
      float vig = smoothstep(1.05, 0.22, dist);
      col *= mix(1.0 - uVignette, 1.0, vig);

      // 冷暖分离：暗部偏蓝，亮部偏暖
      float lum = dot(col, vec3(0.299, 0.587, 0.114));
      col = mix(col, col * vec3(0.90, 0.96, 1.14), (1.0 - lum) * 0.32);
      col = mix(col, col * vec3(1.06, 1.01, 0.94), lum * 0.18);

      // 轻微提亮饱和度，让旋臂的颜色更通透
      float lum2 = dot(col, vec3(0.299, 0.587, 0.114));
      col = mix(vec3(lum2), col, 1.22);

      // 胶片颗粒
      vec2 grainUv = uv * uResolution * 0.5;
      float grain = fract(sin(dot(grainUv + uTime * 17.0, vec2(12.9898, 78.233))) * 43758.5453);
      col += (grain - 0.5) * 0.018;

      gl_FragColor = vec4(max(col, 0.0), 1.0);
    }
  `,
};
