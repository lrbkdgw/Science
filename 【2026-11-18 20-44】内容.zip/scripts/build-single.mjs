/**
 * 把 Vite 产物内联成一个独立的 HTML 文件，
 * 方便不启动服务器、直接双击浏览器打开。
 */
import fs from 'node:fs';
import path from 'node:path';

const distDir = path.resolve('dist');
const indexPath = path.join(distDir, 'index.html');

let html = fs.readFileSync(indexPath, 'utf8');

const scriptTag = html.match(/<script[^>]*\ssrc="([^"]+)"[^>]*><\/script>/);
const styleTag = html.match(/<link[^>]*\srel="stylesheet"[^>]*\shref="([^"]+)"[^>]*>/);

if (!scriptTag || !styleTag) {
  throw new Error('未在 dist/index.html 中找到可内联的 script / stylesheet');
}

const readAsset = (url) =>
  fs.readFileSync(path.join(distDir, url.replace(/^\.?\//, '')), 'utf8');

const js = readAsset(scriptTag[1]).replace(/<\/script/gi, '<\\/script');
const css = readAsset(styleTag[1]).replace(/<\/style/gi, '<\\/style');

// 用函数替换，避免内联代码里的 $& / $` 等被 replace 当作特殊记号
// script 从 head 移到 body 末尾：内联经典脚本会立即执行，必须等 DOM 就绪
html = html.replace(styleTag[0], () => `<style>\n${css}\n</style>`);
html = html.replace(scriptTag[0], '');
html = html.replace('</body>', () => `<script>\n${js}\n</script>\n  </body>`);

const outPath = path.join(distDir, '旋臂之间.html');
fs.writeFileSync(outPath, html);
console.log(`✓ 独立单文件：${path.relative(process.cwd(), outPath)}`);
