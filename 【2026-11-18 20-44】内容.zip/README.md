# 旋臂之间 · 银河

一个使用 Three.js + GLSL 实时渲染的螺旋星系单页。深空、星尘、程序化旋臂云气与电影感辉光。

![预览](./preview.jpg)

## 亮点

- 18 万颗粒子（移动端约 9.5 万）组成四旋臂星系，GLSL 自定义点精灵辉光
- 程序化生成的旋臂云气贴图，让星系拥有雾状纹理，而不只是散点
- 对数螺旋 + 高斯抖动生成旋臂，核心、星晕分层布点
- 8000 余颗背景恒星、深空星云与冷色渐变穹顶
- UnrealBloom 辉光、ACES 色调映射，以及暗角 / 色散 / 胶片颗粒调色
- OrbitControls 阻尼环绕、开场推镜、自动漫游、重置视角、全屏
- 响应式布局，并尊重系统的「减少动态效果」偏好

## 快速体验

直接双击 **`旋臂之间.html`** 即可（需要先解压）。这是把 JS / CSS 全部内联的单文件版本，不需要安装依赖，也不需要联网或启动本地服务器。

## 本地开发

需要 Node.js 18+（开发环境为 Node 22 / Vite 8）。

```bash
npm install
npm run dev
```

打开 http://localhost:5173 。

生产构建：

```bash
npm run build
npm run preview
```

`npm run build` 会先执行 Vite 构建，再由 `scripts/build-single.mjs` 生成单文件版本。构建产物：

- `dist/旋臂之间.html`：单文件版本，双击即开
- `dist/index.html` + `dist/assets/`：常规静态站点，需要通过 HTTP 服务器访问

## 交互

- 鼠标拖拽 / 单指滑动：环绕星系
- 滚轮 / 双指：缩放
- 空格：自动漫游开关
- R：重置视角
- 右下角按钮：自动漫游、重置视角、全屏

## 结构

| 文件 | 说明 |
| --- | --- |
| `src/main.js` | 场景、后处理、交互与启动流程 |
| `src/galaxy.js` | 星系粒子、旋臂云气、核心辉光、星云与星空 |
| `src/shaders.js` | 粒子、天空与调色 GLSL |
| `src/textures.js` | 程序化 Canvas 贴图（星云、雾气、辉光、星芒） |
| `src/style.css` | 界面样式 |
| `scripts/build-single.mjs` | 把构建产物内联成单文件 HTML |
| `dist/` | 已构建好的静态产物 |
